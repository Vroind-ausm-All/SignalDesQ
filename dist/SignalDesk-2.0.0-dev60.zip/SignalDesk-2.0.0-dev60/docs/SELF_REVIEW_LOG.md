# Selbstprüfung je Arbeitspaket

Jede Note (1 = schwach, 5 = stark) nennt den Messwert oder Test, auf den sie sich stützt. Noten ohne Beleg gibt es nicht.
Stufen: implementiert → lokal getestet → live verifiziert → pilotfähig → öffentlich launchfähig.

## Sprint 0 – Wahrheitscheck (11.11.2026)

- **Ergebnis:** `docs/LAUNCH_AUDIT.md`, `docs/ARCHITECTURE_DECISIONS.md`.
- **Wichtigster Befund:** Der neueste Stand lag nicht auf `main`, sondern auf `codex/signaldesk-2.0-dev` (2.0.0-dev1, mit Übergabe). Die Arbeit baut darauf auf.
- **Abweichung von älteren Angaben:** 426 statt 425 Tests auf dev1; 4 statt 2 Überspringungen.
- **Entscheid:** weiter. Größter überprüfbarer Nutzen: Kundenbewertung und Erreichbarkeit (Matrix: zwei Einträge „Defekt“).

## Arbeitspaket 1 – Kundenbewertung und Erreichbarkeit (2.0.0-dev2)

Entspricht aus dem Auftrag: Abschnitt 6 (Zielkundenprofil, Passung vor / Qualifizierung nach dem Gespräch, Gesprächsergebnisse, Zeitfenster, Verlustgründe), Sprint 3 (K.-o.- und Warnkriterien) und Abschnitt 7 (zwei Projekt-Skills).

### Tatsächlich ausgeführt

| Prüfung | Ergebnis |
|---|---|
| Regression `python -m unittest discover -s tests` (Python 3.13, Linux) | 454 Tests bestanden, 4 übersprungen (optionale Pakete) |
| davon neu: `tests/test_v2_qualification.py` | 28 Tests |
| Browser-Tests `tests/e2e` (Chromium, festgeschriebene Pakete) | 3 von 3 bestanden, davon 1 neu (Profil → Note in der Liste → Firmenakte → „nicht erreicht“ → „verloren“ mit Grund) |
| Migration einer Altdatenbank (Stand v1.6) | bestanden; alle Altdaten lassen sich bewerten |
| Release-Paket | 159 Dateien, 1,0 MB, zweimal gebaut und byte-gleich |
| Übersicht für 500 Firmen und 300 Sperreinträge | 0,04 s (vor der Nachbesserung 1,38 s) |
| Windows, macOS, echte Firmen | **nicht geprüft** |

### Bewertung

| Kriterium | Note | Beleg |
|---|---|---|
| Nutzen | 4 | Zwei als „Defekt“ geführte Punkte des Audits sind behoben (Bewertung am Zielmarkt vorbei; „nicht erreicht“ folgenlos). Ob die Noten im Alltag stimmen, ist ungeprüft. |
| Bedienbarkeit | 3 | Browser-Test durchläuft den Weg ohne Anleitung. Die Branchenwahl ist eine Liste mit 60 Auswahlfeldern; die Note steuert noch nicht die Reihenfolge in „Heute“ und Pipeline. |
| Quellenqualität | 4 | Jedes Kriterium nennt seine Grundlage („aus Firmenname geschätzt“, „laut Firmensuche“). Kontaktwege zeigen nur belegte Werte. |
| Robustheit | 4 | Kaputtes gespeichertes Profil fällt auf die Vorgaben zurück; fehlendes Ortsverzeichnis ergibt „unbekannt“ statt Fehler (Tests). |
| Sicherheit | 4 | Auswertung ändert keine Daten (Test); Sperre wirkt als K.-o. und entfernt den Vorschlag für den nächsten Versuch (Test); keine neue Abhängigkeit, kein neuer Netzabruf. |
| Kostenkontrolle | 5 | Keine Netzabfragen, keine KI, keine Fremdpakete. |
| Erweiterbarkeit | 3 | Modul ohne globalen Zustand außer einem Orts-Zwischenspeicher; Gewichte stehen noch fest im Code. |
| Testabdeckung | 4 | 28 Unit-/API-Tests, 1 Browser-Test, 1 Migrationstest. Kein Test auf Windows. |

### Nachbesserungsschleife 1

Auslöser: der neue Browser-Test und die Bildschirmfotos.

1. **Skript wurde nicht ausgeliefert.** `/assessment.js` fehlte in der Liste der statischen Dateien; der Server antwortete mit 404. Alle Unit-Tests waren grün – nur der Browser-Test fiel auf. Behoben; als Regel in den Skill `qa-release-gate` aufgenommen.
2. **Übersicht zu langsam:** 1,38 s für 500 Firmen bei jedem Neuladen. Ursache: Ortssuche je Firma und doppelte Sperrprüfung. Behoben (0,04 s).
3. **Darstellung:** Überschriften der Statistik klebten am Text, das Ankreuzfeld stand über seiner Beschriftung. Behoben.

### Nachbesserungsschleife 2

Auslöser: der vollständige Testlauf nach Schleife 1.

1. **Zwischenspeicher merkte sich Fehlschläge.** War das Ortsverzeichnis einmal nicht verfügbar, blieb die Entfernung dauerhaft „unbekannt“. Im Einzeltest unsichtbar, im Gesamtlauf rot. Jetzt werden nur Treffer gemerkt.
2. **Release-Paket enthielt alte Pakete.** Der Ordner `ausgabe/` (zwei ZIP-Dateien) wanderte in jedes neue Paket: 3,3 MB statt 1,0 MB. `ausgabe/` und `.claude/` sind jetzt ausgeschlossen. Dieser Fehler bestand schon in dev1.
3. **Veralteter Bytecode** täuschte nach dem Versionswechsel die alte Versionsnummer vor (Testumgebung, kein Programmfehler). In den Skill aufgenommen: nach Versionswechsel `__pycache__` leeren.

Schleife beendet, weil alle Prüfungen bestehen und die verbleibenden Schwächen neue Arbeitspakete sind, keine Korrekturen.

### Die drei wichtigsten verbleibenden Schwachstellen

1. **Die Bewertung ist nicht an echten Ergebnissen geprüft.** Gewichte und Schwellen sind gesetzt. Belegbar wird sie erst mit dem Praxistest (50–100 Firmen) und ausreichend gewonnenen und verlorenen Chancen.
2. **Die Note steuert den Arbeitstag noch nicht.** „Heute“, Pipeline und Firmen-Berichte sortieren weiter nach dem alten Lead-Fit. Es stehen jetzt fünf Kennzahlen nebeneinander statt vier; der alte Lead-Fit sollte in der Anzeige ersetzt werden.
3. **Erreichbarkeit ist nur zur Hälfte gelöst.** Geschäftszeiten der Firmen und die eigene Erreichbarkeit (verpasste Anrufe, Rückrufzeiten, Auslastung) fehlen.

### Stufe

| Stufe | Stand |
|---|---|
| Implementiert | ja |
| Lokal getestet (Linux, Chromium) | ja |
| Live verifiziert (echte Firmen, Windows) | nein |
| Pilotfähig | nein – erst nach Praxistest und Windows-Prüfung |
| Öffentlich launchfähig | nein |

**Entscheid:** weiter mit Arbeitspaket 2 (Note in „Heute“ und Pipeline, eigene Erreichbarkeit), sobald freigegeben.

## Arbeitspaket 2 – Eigene Erreichbarkeit und Auslastung (2.0.0-dev3)

Entspricht aus dem Auftrag: Abschnitt 3 („Heute“ mit priorisierten nächsten Aktionen), Abschnitt 6 (Rückrufzusagen, Zeitfenster, verfügbare Kapazität). Behebt die Schwachstellen 2 und 3 aus Arbeitspaket 1 zum Teil.

### Tatsächlich ausgeführt

| Prüfung | Ergebnis |
|---|---|
| Regression (Python 3.13, Linux) | 469 Tests bestanden, 4 übersprungen (optionale Pakete) |
| davon neu: `tests/test_v2_reach.py` | 15 Tests |
| Browser-Tests `tests/e2e` | 4 von 4 bestanden, davon 1 neu (Eingang festhalten und erledigen, Kontaktliste, Auslastung, Note in der Pipeline, eigene Zeiten) |
| Release-Paket | zweimal gebaut, byte-gleich |
| Prüfliste `privacy-and-contact-guardrails` | Punkte 2–5 und 7 eingehalten (Tests: gesperrte Firma nie auf der Kontaktliste, Liste legt nichts an, kein Versand). Punkt 1 bewusst abweichend: ein Eingang lässt sich auch bei gesperrter Firma festhalten, mit Warnhinweis. Punkt 6 verletzt, siehe Schwachstelle 1. |
| Windows, macOS, echte Firmen | **nicht geprüft** |

### Bewertung

| Kriterium | Note | Beleg |
|---|---|---|
| Nutzen | 4 | Ein verpasster Anruf ist in einem Schritt mit Frist festgehalten (Browser-Test). Ob die Fristen im Alltag passen, zeigt erst die Nutzung. |
| Bedienbarkeit | 4 | Eingang und Kontaktliste stehen ganz oben auf „Heute“; ein Feld genügt. Bildschirmfotos geprüft. |
| Quellenqualität | 3 | Die Auslastung nennt ihre Grundlage, bleibt aber eine Schätzung aus kalkulierten Stunden. |
| Robustheit | 4 | Kaputte Einstellungen fallen auf Vorgaben zurück; Fristen überspringen Wochenenden und Abwesenheiten (Tests). Feiertage fehlen. |
| Sicherheit | 4 | Kein Versand, keine Netzabfrage. Gesperrte Firmen erscheinen nie als Kontaktvorschlag (Test). |
| Kostenkontrolle | 5 | Keine Netzabfragen, keine KI, keine Fremdpakete. |
| Erweiterbarkeit | 3 | Modul ohne globalen Zustand; Kalender- und Telefonanbindung hätten klare Anschlussstellen, existieren aber nicht. |
| Testabdeckung | 4 | 15 Unit-/API-Tests, 1 Browser-Test. Kein Test auf Windows. |

### Nachbesserungsschleife 1

Auslöser: Bildschirmfoto von „Heute“.

1. Das Eingabeformular war ungestaltet und klebte am Rand. Behoben.
2. Der Eingang stand unter dem sechszeiligen Tagesplan – für „in zehn Sekunden festhalten“ zu weit unten. Jetzt ganz oben.
3. Listenzeilen nutzten ein dreispaltiges Raster mit zwei Elementen. Behoben.

### Nachbesserungsschleife 2

Auslöser: zweites Bildschirmfoto.

1. **Widerspruch im Tagesplan:** „Wiedervorlagen erledigen“ galt als erledigt, obwohl ein Rückruf offen war. Fällige Rückrufe aus dem Eingang stehen jetzt in der Wiedervorlage (Test).
2. Die Auslastung meldete „Zugesagt sind rund 0 Wochen“, obwohl 40 Stunden angeboten waren. Text korrigiert.
3. Das Etikett „Auslastung“ zog sich über die ganze Breite. Behoben.

Schleife beendet: alle Prüfungen bestehen, die verbleibenden Punkte sind neue Arbeit.

### Die drei wichtigsten verbleibenden Schwachstellen

1. **Einträge im Eingang haben keine Löschfrist.** Sie können Namen und Telefonnummern enthalten und müssen bisher von Hand gelöscht werden. Sollte als Nächstes an die Löschfristen in `quality.py` angeschlossen werden.
2. **Die Auslastung ist grob.** Ohne erfasste Ist-Zeiten zählt jedes angenommene Angebot 8 Wochen lang voll. Verlässlich wird sie erst mit der Nachkalkulation.
3. **Weiterhin ungemessen an echten Firmen und ungetestet unter Windows.** Das gilt für beide Arbeitspakete; der Praxistest braucht eine Freigabe.

Offen aus Arbeitspaket 1 bleibt: „Heute → Offenes Potenzial“ und die Firmen-Berichte sortieren noch nach dem alten Lead-Fit; Geschäftszeiten der Firmen fehlen.

### Stufe

Implementiert und lokal getestet (Linux, Chromium). Nicht live verifiziert, nicht pilotfähig, nicht öffentlich launchfähig.

**Entscheid:** weiter. Vorschlag für Arbeitspaket 3: Praxistest an echten Firmen (nach Freigabe) oder, ohne Freigabe, Löschfrist für den Eingang und README-Neufassung.

## Arbeitspaket 3 – Plattformfestigkeit und Aufräumen (2.0.0-dev4)

Auslöser: Die CI des Pull Requests #19 war rot. Die Prüfung zeigte, dass sie schon bei v1.19 auf `main` rot war – die Fehler waren älter als die Arbeitspakete 1 und 2, wurden aber bisher nicht bemerkt. Im Audit stand dazu nur „Ergebnis des letzten Laufs konnte nicht abgerufen werden“; das war eine Lücke im Wahrheitscheck.

### Befunde und Behebung

| Befund | Wirkung | Behebung | Schutz |
|---|---|---|---|
| Backslash im Ausdruck eines f-Strings (`imprint.py`, seit 04.11.) | **SignalDesk startet unter Python 3.10 und 3.11 nicht**, obwohl 3.10+ zugesagt ist | Ausdruck in eine Variable gelegt | Test durchsucht alle Dateien nach diesem Muster |
| Sonderzeichen (②, ←, ✓) in der Konsolenausgabe | Abbruch von Einrichtung und Installationsprüfung in Windows-Konsolen ohne UTF-8 | Ausgabe ersetzt nicht darstellbare Zeichen | Test mit cp1252-Konsole |
| `with sqlite3.connect(...)` schließt die Verbindung nicht | Datenbankdatei bleibt nach dem Start gesperrt, bis Python aufräumt; unter Windows scheitern Löschen und Ersetzen | Verbindung wird ausdrücklich geschlossen (1 Stelle im Programm, 8 in Tests und Werkzeugen) | Test: keine offene Verbindung nach der Datenbank-Vorbereitung |
| Test baute unter Python < 3.12 einen Windows-Pfad auf Linux | 1 Testfehler unter 3.10 | Pfad vor dem Umschalten angelegt | – |

### Tatsächlich ausgeführt

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13, 3.12 und 3.10 (Linux) | je 473 Tests bestanden; 4 bzw. 6 übersprungen (optionale Pakete) |
| Warnungen „unclosed database“ im Gesamtlauf | 0 (vorher 27) |
| Die drei neuen Schutz-Tests ohne die Behebungen | schlagen fehl – sie prüfen also wirklich |
| Browser-Tests | 4 von 4 |
| Python 3.11 in dieser Umgebung | 4 Fehler durch ein defektes System-Paket `cryptography` der Testmaschine, nicht durch SignalDesk; ohne dieses Paket nicht nachgeprüft |
| Windows | **hier nicht ausführbar.** Die Ursachen wurden aus den CI-Protokollen abgelesen und unter Linux nachgestellt. Ob die Windows-CI jetzt grün ist, zeigt erst der Lauf nach dem Push. |

### Außerdem erledigt

- Eingang: erledigte Einträge werden nach 90 Tagen (einstellbar) anonymisiert – Schwachstelle 1 aus Arbeitspaket 2.
- Note in den Firmen-Berichten.
- README neu (82 statt 432 Zeilen), Roadmap neu.
- Ordner `ausgabe/` entfernt. Die Dateien bleiben im Git-Verlauf abrufbar; sie ganz zu tilgen hieße den Verlauf umzuschreiben und wurde nicht gemacht.

### Bewertung

| Kriterium | Note | Beleg |
|---|---|---|
| Nutzen | 5 | Ohne die erste Behebung startet das Programm auf zwei von vier zugesagten Python-Versionen nicht. |
| Robustheit | 4 | Drei Fehlerklassen mit Schutz-Test abgedeckt; Windows selbst nur über die CI prüfbar. |
| Testabdeckung | 4 | Jetzt lokal auf drei Python-Versionen ausgeführt statt auf einer. |
| Bedienbarkeit | 4 | README führt in 82 Zeilen zum Start und zu den Dokumenten. |

### Die drei wichtigsten verbleibenden Schwachstellen

1. **Windows bleibt unbewiesen, bis die CI grün ist.** Weitere Windows-Fehler können hinter den jetzt behobenen liegen (der Lauf zeigte 19 Fehler; nicht alle Protokollzeilen waren abrufbar).
2. **Der Wahrheitscheck in Sprint 0 war unvollständig:** Der CI-Zustand wurde nicht geklärt. Künftig gehört „CI-Ergebnis gelesen“ zum Prüfverfahren (im Skill ergänzt).
3. **Weiterhin keine Messung an echten Firmen.**

### Nachtrag: CI-Ergebnis für Commit `352d7c8` gelesen

8 von 10 Jobs grün (vorher 4): beide Windows-Installationen, Python 3.10 und 3.13 unter Linux, Browser-Test, Release. Die Unit-Tests unter Windows fielen von 19 auf 2 Fehler. Beide sind in einer zweiten Nachbesserung behoben:

| Befund | Wirkung | Behebung | Schutz |
|---|---|---|---|
| Zwei Wiederherstellungen in derselben Sekunde erzeugten denselben Namen für die Sicherheitskopie | Unter Windows Abbruch; **unter Linux wurde die erste Sicherheitskopie stillschweigend überschrieben** | eindeutiger Name, nie überschreiben | Test: beide Sicherheitskopien bleiben erhalten |
| Recherche-Worker fragen die Datenbank noch Sekunden nach dem letzten Auftrag ab | Unter Windows blieb die Datei beim Aufräumen eines Tests gesperrt | `jobs.stop_workers()` beendet die Worker sauber; laufende Schritte werden zu Ende geführt, offene bleiben eingereiht | Test: Beenden und Neustart der Worker |

Danach lokal: 475 Tests unter Python 3.13 und 3.10 bestanden. Ob Windows damit vollständig grün ist, zeigt der nächste CI-Lauf.

**Entscheid:** nachbessern abgeschlossen; CI des neuen Commits lesen.

### Nachtrag: CI-Ergebnis für Commit `cc584f2` gelesen

9 von 10 Jobs grün. **Die Unit-Tests unter Windows mit Python 3.13 sind erstmals vollständig grün.** Unter Windows mit Python 3.10 blieb 1 Fehler: derselbe Sammelsuche-Test konnte seine Datenbankdatei beim Aufräumen nicht löschen (unter 3.13 im selben Lauf bestanden – ein Zeitproblem, kein fester Fehler). Der Test versucht das Aufräumen jetzt bis zu zehn Sekunden lang erneut; die Worker enden beim Beenden sofort statt nach bis zu fünf Sekunden. Die Prüfungen des Tests selbst sind unverändert. Ob das reicht, zeigt der nächste Lauf; die eigentliche Ursache (welcher Hintergrund-Thread die Datei kurz hält) ist nicht nachgewiesen.

### Nachtrag: CI-Ergebnis für Commit `5db25ba` – Ursache belegt

Wieder 1 Fehler unter Windows, diesmal in einem **anderen** Test (`test_sprintS3_jobs`, startet echte Recherche-Worker). Damit ist die Ursache belegt statt vermutet: Die Worker fragen die Datenbank weiter ab, während der Test sie löscht. Welcher Test es trifft, hängt vom Zeitpunkt ab. Behebung an einer Stelle statt Test für Test: `tests/tmpclean.py` beendet vor dem Löschen alle Worker (`jobs.stop_all_workers`) und wird von allen 27 Testdateien mit temporärer Datenbank verwendet. Laufzeit unverändert (137 s). Prüfungen der Tests unverändert.

**Eigener Fehler in dieser Runde:** Commit `02a3a0d` wurde gepusht, bevor das Testergebnis gelesen war. Er wartete auch auf Sammelsuchen früherer Tests und brach 20 Tests. Im Folge-Commit behoben; der erste Versuch der Korrektur verdreifachte außerdem die Laufzeit (400 statt 140 Sekunden) und wurde zurückgenommen. Regel im Prüfverfahren ergänzt: Commit und Push nie im selben Befehl wie den Testlauf ausführen.

## Arbeitspaket 4 – Nachkalkulation (2.0.0-dev5)

Entspricht aus dem Auftrag: Abschnitt 6 („verfügbare Kapazität, Nachkalkulation bei abgeschlossenen Projekten“). Behebt Schwachstelle 2 aus Arbeitspaket 2 (grobe Auslastung).

### Tatsächlich ausgeführt

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 (Linux) | je 485 Tests bestanden; 4 bzw. 6 übersprungen (optionale Pakete) |
| davon neu: `tests/test_v2_postcalc.py` | 10 Tests |
| Browser-Tests | 5 von 5, davon 1 neu (Zeit erfassen → Rest sichtbar → abschließen → Urteil → Auslastung auf „Heute“ folgt) |
| Release-Paket | zweimal gebaut, byte-gleich |
| Windows, echte Firmen | nicht geprüft; Windows nur über die CI |

### Bewertung

| Kriterium | Note | Beleg |
|---|---|---|
| Nutzen | 4 | Beantwortet erstmals „Hat sich der Festpreis gelohnt?“ (Test: 74,00 € je Stunde gegen 66 € Mindestverdienst). Wert hängt davon ab, dass Zeiten wirklich eingetragen werden. |
| Bedienbarkeit | 4 | Ein Feld und ein Knopf je Auftrag; Sammeleinträge erlaubt. Bildschirmfoto geprüft. |
| Quellenqualität | 4 | Soll kommt aus der gespeicherten Kalkulation des Angebots, Ist aus den Einträgen; der Lernwert erscheint erst ab drei Aufträgen. |
| Robustheit | 4 | Abgeschlossene Aufträge sind geschützt; Angebote ohne kalkulierte Stunden führen nicht zu Fehlern (Tests). |
| Sicherheit | 5 | Keine Netzabfrage; Angebote und Rechnungen bleiben unverändert (Test); nichts davon erscheint im Kundendokument. |
| Kostenkontrolle | 5 | Keine Fremdpakete, keine KI. |
| Erweiterbarkeit | 3 | Zeiten hängen am Auftrag, nicht an der einzelnen Leistung. |
| Testabdeckung | 4 | 10 Unit-/API-Tests, 1 Browser-Test. |

### Nachbesserungsschleife 1

Auslöser: der neue Browser-Test.

1. **Das Stundenfeld lehnte „12,5“ ab.** Der Browser erlaubte wegen der eingestellten Schrittweite nur Werte wie 0,1 / 0,35 / 0,6. Das Formular ließ sich nicht absenden – ohne Fehlermeldung. Alle Unit-Tests waren grün. Behoben.
2. Meldungen nutzten den Dezimalpunkt („7.5 von 20“). Jetzt deutsche Schreibweise.
3. Die Grenze von 24 Stunden je Eintrag verhinderte Sammeleinträge („diese Woche 30 Stunden“). Auf 200 angehoben.

### Nachbesserungsschleife 2

1. „1 Einträge“ → „1 Eintrag“.
2. Der bestehende Auslastungs-Test prüfte einen Hinweistext, der sich mit der neuen Rechnung geändert hat; die Prüfung wurde auf die neue Aussage umgestellt und um die Zahl der Aufträge ohne Zeiten ergänzt.

Schleife beendet: alle Prüfungen bestehen.

### Die drei wichtigsten verbleibenden Schwachstellen

1. **Zeiten je Auftrag, nicht je Leistung.** Welche Katalogleistung regelmäßig länger dauert, lässt sich noch nicht ablesen – genau das würde die Preise verbessern.
2. **Aufträge ohne erfasste Zeiten** fallen nach acht Wochen weiterhin still aus der Auslastung.
3. **Weiterhin keine Messung an echten Firmen**; Windows nur über die CI belegt.

### Stufe

Implementiert und lokal getestet (Linux, Python 3.10 und 3.13, Chromium). Nicht live verifiziert, nicht pilotfähig, nicht öffentlich launchfähig.

**Entscheid:** weiter.

## Arbeitspaket 5 – Praxistest 70191 (2.0.0-dev6)

Erste Messung gegen die echten Quellen, mit Freigabe des Eigentümers. Vollständiger Bericht: `PRAXISTEST_70191.md`.

- **Stufe „live verifiziert“ erstmals für einen Teil erreicht:** die Firmensuche gegen GLEIF (und teilweise OpenStreetMap). Website-Zuordnung, Impressum und Firmen-Bericht bleiben ungemessen.
- **Zwei Programmfehler gefunden, die kein Test mit Attrappen zeigen konnte:** PLZ wurde ignoriert (2 von 300 Treffern in der gewünschten PLZ); die erste Quelle verbrauchte das ganze Budget. Beide behoben, mit 6 neuen Tests; Wiederholung live: 56 von 56 Treffern in 70191, alle drei Quellen gelaufen.
- **Wichtigste Erkenntnis:** Für die Zielgruppe Handwerk liefert die Suche heute praktisch nichts (1 von 56). Ursache sind die Quellen, nicht die Bewertung oder die Oberfläche. Die Arbeitspakete 1 und 2 haben damit an einem Teil gearbeitet, der erst nach einer brauchbaren Quelle Wert entfaltet – die Reihenfolge der Roadmap ist entsprechend umgestellt.
- **Ausgeführt:** 491 Tests unter Python 3.13 und 3.10 bestanden.
- **Nicht umgangen:** Der sichere Website-Abruf scheiterte in der Testumgebung an fehlender Namensauflösung. Der Schutz (Verbindung nur zur selbst geprüften Adresse) wurde nicht gelockert, um ein Messergebnis zu erzwingen.

**Die drei wichtigsten Schwachstellen:** (1) keine verlässliche Quelle für Handwerksbetriebe; (2) Website-Zuordnung weiter ungemessen; (3) Branche bei zwei Dritteln der Treffer unbekannt.

**Entscheid:** weiter mit dem lokalen OpenStreetMap-Auszug.

## Arbeitspaket 6 – OpenStreetMap manuell und offline (2.0.0-dev7)

Vorgabe des Eigentümers: Suche ohne festgelegte Branche; OpenStreetMap auf „manuell“; Wege mit geringem Aufwand zeigen, die Quelle nutzbar zu machen.

### Tatsächlich ausgeführt

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 504 Tests bestanden |
| davon neu: `tests/test_v2_osm_local.py` | 13 Tests |
| Browser-Tests | 6 von 6, davon 1 neu: Anleitung, Datei einlesen, Suche in einer PLZ – **ohne einen einzigen Abruf außerhalb des eigenen Rechners** |
| Leser gegen das offizielle Werkzeug `osmium` | Knoten, Koordinaten (auch negative), Umlaute, Gebäudeumrisse stimmen überein |
| Tempo an erzeugter Datei (3 Mio. Knoten, 200.000 Wege) | 4,5 s, 59 MB Arbeitsspeicher |
| Echter Geofabrik-Auszug | **nicht geprüft** – Download in der Testumgebung nach Freigabe des Hosts weiterhin abgebrochen |

### Bewertung

| Kriterium | Note | Beleg |
|---|---|---|
| Nutzen | 4 | Die einzige Quelle mit kleinen Betrieben ist nicht mehr von überlasteten Servern abhängig. Der Nachweis an echten Daten fehlt. |
| Bedienbarkeit | 4 | Ein Kasten mit Stand, drei Wegen samt Aufwand und einem Knopf; Bildschirmfoto geprüft. |
| Quellenqualität | 4 | Lizenz und Stand des Bestands werden genannt; Einträge ohne PLZ werden bei PLZ-genauer Suche ehrlich als fehlend gemeldet. |
| Robustheit | 4 | Kaputte, abgeschnittene und fremde Dateien führen zu einer Meldung (Tests). |
| Sicherheit | 4 | Obergrenzen für Block- und Dateigröße; keine E-Mail-Adressen und Betreibernamen gespeichert (Test). |
| Kostenkontrolle | 5 | Keine Abhängigkeit, kein Netz nötig. |
| Erweiterbarkeit | 3 | Gebäudeumrisse ohne Koordinaten; PLZ-Zuordnung nur über die Adressangabe. |
| Testabdeckung | 4 | Echtes Dateiformat als Testdatei, aber kein großer echter Auszug. |

### Nachbesserung

1. Sieben bestehende Tests prüften den Online-Abruf, der jetzt nur noch auf Wunsch läuft; sie fordern ihn nun ausdrücklich an. Ihre Prüfungen sind unverändert.
2. Gebäudeumrisse fielen in der Umkreissuche ganz heraus; sie zählen jetzt über den Ortsnamen.
3. Bei widersprüchlicher PLZ-Angabe am Eintrag gilt die Angabe, nicht das abgefragte Gebiet.

### Die drei wichtigsten verbleibenden Schwachstellen

1. **Kein Test an einem echten Auszug.** Der erste Lauf beim Eigentümer ist der eigentliche Nachweis.
2. **Einträge ohne PLZ** fehlen bei PLZ-genauer Suche; wie viele das sind, ist ungemessen.
3. **Telefon und Öffnungszeiten** liegen im Bestand, erscheinen aber noch nirgends.

**Entscheid:** weiter; Praxistest mit echtem Auszug durch den Eigentümer.

## Arbeitspaket 7 – OpenStreetMap ausgebaut (2.0.0-dev8)

Behebt die Schwachstellen 2 und 3 aus Arbeitspaket 6.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 508 Tests bestanden |
| Browser-Tests | 6 von 6 |
| Einlesen mit zweitem Durchlauf (3 Mio. Punkte, 4.000 Umrisse) | 4,9 s, 41 MB Arbeitsspeicher |
| Echter Geofabrik-Auszug | weiterhin nicht geprüft |

- **PLZ-Schätzung:** 250 m zum nächsten Betrieb mit PLZ; Test belegt, dass ein weit entfernter Nachbar nicht zählt und eine eigene Angabe nie überschrieben wird. Die Trefferquote an echten Daten ist ungemessen.
- **Lage der Umrisse:** gegen die mit `osmium` erzeugte Datei geprüft.
- **Öffnungszeiten:** bewusst enger Leser; sechs unklare Schreibweisen ergeben „unbekannt“ statt einer falschen Aussage (Test).
- **Nachbesserung:** Der Browser-Test wartete nicht auf das Ende der Suche und bestand deshalb zufällig mit einem Zwischenstand. Er prüft jetzt den fertigen Lauf und die erwarteten vier Treffer.

**Verbleibende Schwachstellen:** (1) kein Test an einem echten Auszug; (2) Güte der PLZ-Schätzung an PLZ-Grenzen ungemessen; (3) Öffnungszeiten steuern die Kontaktreihenfolge noch nicht.

**Entscheid:** weiter; der echte Auszug beim Eigentümer ist der nächste Nachweis.

## Arbeitspaket 8 – Größere Zielgruppe (2.0.0-dev9)

Vorgabe des Eigentümers: Betriebe ohne Rechtsform einbeziehen und kennzeichnen. Dazu die nächsten Roadmap-Punkte.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 516 Tests bestanden |
| Browser-Tests | 6 von 6; der OpenStreetMap-Test prüft jetzt auch die Kennzeichnung und „Alle Treffer übernehmen“ |
| Sperrliste bei der Sammelübernahme | Widerspruch nach der Suche eingetragen → Treffer wird übersprungen (Test) |

**Fehler während der Arbeit:** Ein Kommentar, den ich mitten in eine Zeile setzte, schaltete die Einstellung „Websites automatisch suchen“ ab. Ein bestehender Test fiel sofort auf; behoben vor dem Commit.

**Bewertung:** Nutzen 4 (mehr Treffer, ohne Messung an echten Daten), Bedienbarkeit 4 (Bildschirmfoto der Trefferliste geprüft), Sicherheit 3 – die Zielgruppe enthält jetzt bewusst Einträge mit möglichem Personenbezug; SignalDesk kennzeichnet sie, prüft aber keine Rechtsgrundlage.

**Die drei wichtigsten Schwachstellen:** (1) Personenbezug bei Betrieben ohne Rechtsform: Kennzeichnung ja, aber keine eigene Löschfrist und kein Art.-14-Baustein für diese Leads; (2) Tempo der Sammelübernahme bei mehreren tausend Treffern ungemessen; (3) weiterhin kein Lauf mit echtem OpenStreetMap-Auszug.

**Entscheid:** weiter.

### Nachtrag: CI-Ergebnis für Commit `a08c5d1`

Unter Windows mit Python 3.13 schlug `test_malformed_requests_never_500` fehl: Bei einer absichtlich kaputten Anfrage brach die Verbindung ab (`WinError 10053`), statt dass eine Fehlermeldung ankam. Ursache: Lehnt der Server eine Anfrage ab, bevor er ihren Körper gelesen hat, und schließt dann die Verbindung, bricht Windows sie hart ab. Unter Linux kommt die Antwort trotzdem an; deshalb fiel es nur dort auf.

Behebung im Server, nicht im Test: Nach jeder Anfrage liest der Server den ungelesenen Rest des Körpers (bis 1 MB) ein; bei größeren Körpern wird die Verbindung nicht weiterverwendet. Zwei neue Tests: einer prüft den Mechanismus direkt und schlägt ohne die Behebung fehl, einer prüft das Verhalten von außen. Der Nachweis unter Windows steht mit dem nächsten CI-Lauf aus. 518 Tests unter Python 3.13 und 3.10 bestanden.

## Arbeitspaket 9 – Datenschutz für Betriebe ohne Rechtsform (2.0.0-dev10)

Behebt Schwachstelle 1 aus Arbeitspaket 8.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 527 Tests bestanden (9 neu) |
| Browser-Tests | 6 von 6; der OpenStreetMap-Test prüft jetzt auch Hinweis und Verlängerung in der Firmenakte |
| Migration einer Datenbank mit Schema 28 | Nachweise für bereits übernommene Betriebe nachgezogen, einmalig (Test) |

- **Löschen ist bewusst eng gefasst:** Kunden und Firmen im laufenden Gespräch werden nie still gelöscht; eine Sperre überlebt die Löschung (Test); der Löschnachweis enthält keinen Namen (Test).
- **Fehlersuche im Browser-Test:** Er schlug nur im Bildschirmfoto-Modus fehl, weil die Firmenakte nach dem Verlängern neu gezeichnet wurde, während das Foto entstand. Mein erster Erklärungsversuch (Klick auf eine neu gezeichnete Listenzeile) war falsch und wurde zurückgenommen.

**Verbleibende Schwachstellen:** (1) Die Rechtsgrundlage wird nicht im Einzelfall geprüft; (2) der Art.-14-Hinweis muss von Hand versendet und vermerkt werden; (3) weiterhin kein Lauf mit echtem OpenStreetMap-Auszug.

**Entscheid:** weiter mit Roadmap und Oberfläche.

## Arbeitspaket 10 – Darstellung: Themes, Hell/Dunkel, Kompakt (2.0.0-dev11)

Auftrag: Oberfläche übersichtlicher machen, Vorschläge in Hell und Dunkel, mehrere Themes in den Einstellungen wählbar; danach Roadmap.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 537 Tests bestanden (10 neu) |
| Browser-Tests | 7 von 7 (1 neu: umschalten, nach Neuladen erhalten, frischer Browser übernimmt die Wahl vom Server, „Wie System“ folgt dem Betriebssystem, keine Abrufe nach außen) |
| Kontrast | 4 Themes × 2 Modi × 24 Farbpaare gegen WCAG; anfangs 21 Verstöße, nach Anpassung 0 (Test) |
| Feste Farben | 284 Farbwerte in 42 Rollen; Test schlägt bei jeder neuen festen Farbe fehl (mit eingebautem Fehler geprüft) |
| Abweichung „Klassisch“ zum Stand davor | Farbwert für Farbwert gegen das alte Stylesheet verglichen: Markenfarben gleich, 67 sichtbar verschobene Töne, vor allem Grautöne und Linien |
| Messung bei 1366 × 768 | Kompakt: Seitenkopf 255 → 162 px, sichtbare Lead-Zeilen 5 → 8 |
| Release-Paket | enthält `theme.js`, `appearance.py`, Vorschlagsdokument |

**Selbstbewertung 4 von 5.** Abzug, weil „Klassisch“ nicht pixelgleich geblieben ist und durchscheinende Schatten (48 Stellen) noch feste Werte tragen.

Nachbesserungen innerhalb des Pakets:
1. Der erste Rollenentwurf hatte die Markenfarbe Mint durch ein helleres Mint ersetzt und Texte in der dunklen Seitenleiste an das Grau für helle Flächen gekoppelt. Gefunden durch den Farbvergleich gegen die alte Datei; behoben mit eigener Rolle für Nebentexte in der Seitenleiste.
2. „Kompakt“ vergrößerte versehentlich die Abstände der Seitenleiste, weil die Regel spezifischer war als die vorhandene. Im Bildschirmfoto gefunden und entfernt. Danach brachte Kompakt nur 37 px; erst das Ausblenden der Erklärtexte ergab die gemessenen 93 px.

**Verbleibende Schwachstellen:** (1) Darstellung je Installation, nicht je Nutzer; (2) der Lead-Dialog ist rund 7.800 px lang – Vorschlag V2 in `UI_UX_VORSCHLAEGE.md`; (3) weiterhin kein Lauf mit echtem OpenStreetMap-Auszug.

**Entscheid:** Vorschläge V2–V9 dem Eigentümer zur Auswahl vorlegen; Empfehlung V2 → V3 → V6.

## Arbeitspaket 11 – Firmenakte mit Reitern, einheitliche Statusmarken (2.0.0-dev12)

Auftrag: weitermachen nach dem Merge von dev10/dev11; umgesetzt wurden die empfohlenen Vorschläge V2 und V6 aus `UI_UX_VORSCHLAEGE.md`.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 543 Tests bestanden (6 neu) |
| Browser-Tests | 8 von 8 (1 neu: Kopf, jeder Reiter zeigt genau seinen Bereich, Tastatur, Sprung in verdeckten Reiter, neuer Lead ohne Reiter); die älteren Tests, die in der Firmenakte klicken, laufen unverändert |
| Kein Element verloren | alle 27 IDs des Dialogs vor dev12 vorhanden, jedes im fachlich richtigen Reiter (Test) |
| Länge | längster Reiter 2.322 px statt rund 7.800 px für den ganzen Dialog (1366 × 768, Test verlangt unter 4.000 px) |
| Statusmarken | jede der fünf Stufen mit Symbol; negative Zustände in sechs Skripten von „off“ auf „bad“ umgestellt (Test) |

**Selbstbewertung 4 von 5.** Abzug, weil Filter- und Zählerchips noch eigene Formen haben und die Reiter keine Zähler zeigen (etwa offene Aufgaben).

Nachbesserung innerhalb des Pakets: Im ersten Entwurf stand im Reiter „Kontakt & Verlauf“ das Aktivitätsprotokoll ganz unten unter der Entscheider-Recherche – im Bildschirmfoto gesehen und nach oben gezogen, weil es die häufigste Handlung ist.

**Verbleibende Schwachstellen:** (1) Einstellungen weiter verstreut (V3 offen); (2) Darstellung je Installation; (3) weiterhin kein Lauf mit echtem OpenStreetMap-Auszug.

**Entscheid:** als Nächstes V3 (Bereich Einstellungen), dann V4 (Navigation).

## Arbeitspaket 12 – Produktreview Etappe A (2.0.0-dev13)

Auftrag: nächsten Sprint umsetzen und die Roadmap mit dem externen Produktreview vom 13.11.2026 abgleichen. Das Review prüfte
dev11 und empfahl, vor dem Menüumbau zuerst Eingabeschutz, Öffnungsfokus und eine eindeutige Bewertung umzusetzen. Deshalb
wurde der geplante Bereich „Einstellungen“ auf dev14 verschoben.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 554 Tests bestanden (11 neu in `tests/test_v2_review_etappe_a.py`) |
| Browser-Tests | 9 von 9 (neu `test_formguard_browser.py`: Abnahmefälle T02, T03, T04 des Reviews); zwei ältere Tests prüfen jetzt die korrigierten Texte |
| Erstellungswege ohne erfundene Werte | Formular, Schnittstelle, CSV-Import, „Bericht für Website“, Firmensuche (Test), Impressumsprüfung (Code) |
| Prüffall K01 | Logo „Basis“: Kundenteil nennt keine widersprechende Pauschalzahl mehr (Test) |
| Release-Paket | gebaut, enthält `formguard.js` |

**Selbstbewertung 4 von 5.** Abzug: Der Eingabeschutz gilt nur im Lead-Dialog, und M21 (Pilot mit echter Referenzliste) bleibt offen – er lässt sich in dieser Umgebung nicht ausführen.

Nachbesserungen innerhalb des Pakets:
1. Leere Schritte im Tagesplan wurden zunächst weiter durchgestrichen dargestellt und dann wegen eines gleichnamigen CSS-Klassennamens („empty“) zentriert – beides im Bildschirmfoto gesehen und mit eigener Klasse behoben.
2. Bei der Suche nach Erstellungswegen fielen zwei weitere Stellen auf, die die Leistung still vorbelegten (Impressumsprüfung, „Bericht für Website“); beide mitbehoben.

**Abweichungen vom Review, bewusst:** Nicht gespeicherte Eingaben bleiben nur im Arbeitsspeicher (keine lokal gespeicherten Entwürfe), weil Gesprächsnotizen nicht unbemerkt auf der Festplatte liegen sollen. Die Firmenakte bleibt vorerst ein Dialog mit Reitern; ob sie eine eigene Seite wird, entscheidet sich mit den direkten Adressen in dev14.

**Entscheid:** weiter mit Etappe B (dev14: Einstellungen und sechs Bereiche mit direkten Adressen).

## Arbeitspaket 13 – Sechs Bereiche und Einstellungen (2.0.0-dev14)

Auftrag: nächsten Sprint fertigstellen – laut abgeglichener Roadmap Etappe B, Teil 1 (Review M06, M07).

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 560 Tests bestanden (6 neu in `tests/test_v2_navigation.py`) |
| Browser-Tests | 10 von 10 (neu `test_navigation_browser.py`: Bereiche, Adressen, Neuladen, Zurück/Vor, Firma per Adresse, Filter in der Adresse, Einstellungen, schmaler Bildschirm; Abnahmefall **T05**). Fünf ältere Tests navigieren jetzt über die Bereiche statt über „Erweitert“. |
| Zuordnung | alle 16 bisherigen Menüziele als Reiter oder Hilfe-Verweis erreichbar (Test), Tabelle in `ROADMAP.md` |
| Struktur | keine doppelten IDs, kein Abschnitt außerhalb einer Ansicht (Test, mit eingebautem Fehler geprüft) |
| Release-Paket | gebaut, enthält `nav.js` |

**Selbstbewertung 4 von 5.** Abzug: Adressen fehlen noch für Filter weiterer Listen und für Firmen-Berichte; die Frage „Firmenakte als eigene Seite“ ist bewusst offen.

Gefunden und behoben während des Pakets:
1. Der Abschnitt „Wiederkehrende Recherche“ landete beim Verschieben hinter statt in der Ansicht „Recherche & Berichte“ und wäre auf jeder Seite erschienen. Der Browser-Test fiel darüber; ein Strukturtest verhindert es künftig.
2. Ein Klick auf einen Bereich öffnete zunächst die zuletzt benutzte Unteransicht. Das Review verlangt eine klare Standardansicht je Bereich – geändert.
3. Am Bereich „Einstellungen“ erschien ein Hinweispunkt, weil der KI-Status als Zähler galt – nur echte Zähler setzen den Punkt.
4. Die Einstellungen luden zunächst die ganze Angebotsansicht nach; dabei kam eine 400-Antwort der Angebotsliste bei unvollständigen Testdaten zum Vorschein. Geladen werden jetzt nur Katalog und Kalkulationsgrundlagen.
5. **Bestehender Fehler:** Der App-Start lief los, bevor alle Skripte geladen waren („renderPipeline is not defined“ beim Neuladen). Durch zwei weitere Skripte trat das häufiger auf; der Start wartet jetzt auf das vollständige Laden.

**Entscheid:** weiter mit dev15 (Review M08-Rest, M09, M11: Heute als Fokusliste, Filterchips und gespeicherte Ansichten, geführter Einstieg).

## Arbeitspaket 14 – Fokusliste, Arbeitsansichten, Einstieg (2.0.0-dev15)

Auftrag: nächsten Schritt ausarbeiten – laut Roadmap Etappe B, Teil 2 (Review M08, M09, M11).

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 570 Tests bestanden (9 neu in `tests/test_v2_focus.py`) |
| Browser-Tests | 11 von 11 (neu `test_focus_leadlist_browser.py`: Fokus, Erste Schritte, Arbeitsansichten, gespeicherte Ansicht, Leerzustand, Spalten, Start mit verzögertem Skript; Abnahmefall **T01**) |
| Reihenfolge | überfällige Zusage vor Termin vor heute Fälligem vor Nachfassen; Rückrufzusage vor A-Passung (Test) |
| Release-Paket | gebaut, enthält `focus.py` und `leadlist.js` |

**Selbstbewertung 4 von 5.** Abzug: Stapelaktionen fehlen noch, und die Fokus-Reihenfolge ist eine feste Regel, die erst der Pilot bestätigen muss.

Korrektur eines früheren Eintrags: In Arbeitspaket 13 stand der Startfehler („renderPipeline is not defined“) als behoben. Er war es nicht vollständig – die Prüfung `readyState === 'loading'` greift bei verzögerten Skripten nie, drei grüne Läufe waren Zufall. Jetzt wartet der Start immer auf `DOMContentLoaded`; ein Browser-Test lädt ein Skript absichtlich verzögert. Mit der alten Prüfung schlägt dieser Test fehl (geprüft).

**Entscheid:** Etappe B ist abgeschlossen. Weiter mit Etappe C – zuerst M12 (ein gemeinsamer Leistungskatalog mit Migration), danach M13 (mehrere Verkaufschancen je Firma).

## Arbeitspaket 15 – Zentraler Leistungskatalog (2.0.0-dev16)

Auftrag: zwei zusätzliche Dokumente vom 13.11.2026 (Bewertungsmodell für Websites, Leitfaden Kundenonboarding) auf Relevanz für M12 prüfen und passend einbauen. Ergebnis der Prüfung: Für M12 relevant sind die gemeinsame Leistungskennung, der Umfang je Leistung (Korrekturschleifen, Nutzungsrechte/Quelldateien, Betrieb/Schnittstellen), der Zahlungsplan als Vorgabe und die Abgrenzung der Analyseangebote (M31). Alles Übrige gehört zu anderen Maßnahmen und steht als M27–M39 in der Roadmap.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 585 Tests bestanden (15 neu in `tests/test_v2_catalog.py`; ältere Tests des Paket-Rechners in sechs Dateien rechnen jetzt über den Katalog) |
| Browser-Tests | 12 von 12 (neu `test_catalog_browser.py`: Vorlagen und Herkunft, geänderter Katalogwert in Vorlage, Hilfe-Karte und Angebot, Korrekturschleifen, Prüfpunkte nur intern, gespeichertes Angebot unverändert) |
| M12-Abnahme | geänderte Leistung gleich in Vorlage, Empfehlung, Angebot, Oberfläche; gespeicherte Angebote (auch im Format bis dev15) unverändert nach Katalog- und Grundlagenänderung und Neustart; Zuordnung 5/6/26 (+5) vollständig; K01 |
| Release-Paket | gebaut, enthält `catalog.py` und `LEISTUNGSKATALOG.md` |

Fehlerschleifen: (1) Der Browser-Test zeigte, dass die Angebotskarten der Hilfe nach einer Katalogänderung bis zum Neuladen den alten Preis behielten – behoben (Karten und Auswahl werden nach dem Speichern neu geladen). (2) Beim Prüfen der Vorlage „Conversion“ fiel ein bestehender Widerspruch auf: „Nicht enthalten: Texte (separate Position)“ neben einer Textposition – behoben.

**Selbstbewertung 4 von 5.** Abzug: Titel, Ausschlüsse und Vorlagen sind noch nicht in der Oberfläche änderbar, und die Abweichung der früheren Paketpreise kann nur der Eigentümer fachlich bewerten.

**Entscheid:** Vor dem Modellumbau M13 kommt ein P0-Paket aus den Ergänzungen (dev17): M27 Begriffe der Website-Bewertung, M35 Versandfassung, M36 Übergang nach Annahme.

## Arbeitspaket 16 – Versandfassung, Projektstart, Begriffe (2.0.0-dev17)

Auftrag: „Erstelle bitte jedes Mal einen PR und arbeite direkt am nächsten Schritt“ – laut Roadmap das P0-Paket aus den Ergänzungen (M27, M35, M36) vor dem Modellumbau M13.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 601 Tests bestanden (16 neu in `tests/test_v2_offer_flow.py`; vier ältere Tests geben die Versandfassung vor dem Versand frei) |
| Browser-Tests | 13 von 13 (neu `test_offer_flow_browser.py`: Entwurf-Download, Freigabe nur mit Prüfpunkten, Download mit Stand, Versand, Zusage, Projektstart ohne Duplikat) |
| Migration | Schema 29 → 30; Altbestand aus `fixtures/migration/v1_6.sql` mit einem versendeten Angebot: Spalten ergänzt, Angebot unverändert, gilt als Entwurf |
| Release-Paket | gebaut, enthält `offer_flow.py` und `offerflow.js` |

Fehlerschleifen: (1) `$$` nimmt in dieser App nur einen Selektor – die erste Fassung von `offerflow.js` hätte im Browser nichts gefunden; ein Strukturtest verhindert die Wiederholung. (2) Der Browser-Test zeigte, dass der Projektstart nach bewusst abgewählten Vorschlägen dauerhaft „offen“ blieb – jetzt gilt er als erledigt, sobald er übernommen ist und keine Nachfassaufgabe mehr offen ist. (3) Beim Prüfen der Begriffe fiel auf, dass eine unbekannte Branche die Profilnähe auf 25 drückte – behoben.

**Selbstbewertung 4 von 5.** Abzug: Die Versandfassung ist Markdown; ein gestaltetes PDF entsteht weiterhin außerhalb, und die Wiedervorlage nach dem Versand ist noch fest 7 Tage.

**Entscheid:** Weiter mit M13 (mehrere Verkaufschancen je Firma) als eigenem Modellumbau mit Migration und Prüfung an einer Kopie vorhandener Daten.

## Arbeitspaket 17 – Verkaufschancen je Firma, Teil 1 (2.0.0-dev18)

Auftrag: nach dem PR direkt am nächsten Schritt weiterarbeiten – laut Roadmap M13. Weil Phase und Bedarf heute in rund 30 Dateien an der Firma hängen, ist M13 in zwei Teile geteilt (Entscheidung E9).

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 610 Tests bestanden (9 neu in `tests/test_v2_chances.py`) |
| Browser-Tests | 14 von 14 (neu `test_chances_browser.py`: Chancen in der Akte, zweite Chance, Verlust nur mit Grund, Auswahl im Angebot und beim Termin) |
| Migration | Kopie einer älteren Datenbank (Vorlage v1.6 plus fünf Firmen in verschiedenen Phasen): genau eine erste Chance je Firma mit Verkaufsbezug, Angebote und Termine zugeordnet, Firmenphasen unverändert, zweiter Start ohne Duplikate |
| Abnahme T08 | zwei offene Chancen mit getrennten Phasen, Anliegen und Terminen; Verlust einer Chance lässt die andere offen und Rechnungen unverändert |
| Release-Paket | gebaut, enthält `chances.py` und `chances.js` |

Fehlerschleifen: (1) Die Vorlage der Altdatenbank trägt ihre Schemaversion nur im Kommentar – der Migrationstest setzt sie jetzt ausdrücklich, sonst wäre die Migration im Test nie gelaufen. (2) Bei zwei gleichzeitig verlorenen Chancen nahm die Firma den Grund der falschen Chance – jetzt zählt die zuletzt geänderte. (3) Die Chancen-Auswahl im Angebot bot bei genau einer offenen Chance eine überflüssige Option „automatisch“ – entfernt.

**Selbstbewertung 4 von 5.** Abzug: Bedarfsanalyse und Freigabe hängen noch an der Firma, und Pipeline/Heute zeigen noch keine einzelnen Chancen – das ist Teil 2 und so dokumentiert.

**Entscheid:** Weiter mit M13 Teil 2 (dev19).

## Arbeitspaket 18 – Bedarf und Freigabe je Chance, Pipeline und Heute (2.0.0-dev19)

Auftrag: weitermachen, wo aufgehört wurde – M13 Teil 2.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 616 Tests bestanden (6 neu in `tests/test_v2_chances_need.py`, darunter ein Strukturtest; ein älterer Test bestätigt den Bedarf jetzt an der Chance des Angebots) |
| Browser-Tests | 15 von 15 (`test_chances_browser.py` klickt jetzt eindeutig auf „Chance speichern“, weil die Karte zusätzlich das Freigabe-Formular hat; neu `test_chance_need_browser.py`: Auswahl der Chance in der Bedarfsanalyse, Speichern ohne Firmenänderung, Freigabe an der Chance, Angebot aus ihrem Bedarf, Pipeline-Karten je Chance) |
| Abnahme | Freigabe einer Chance gilt nicht für eine andere; Angebote prüfen den Bedarf ihrer Chance; T08 vollständig |
| Migration | Schema 31 → 32, neue Spalten mit Vorgabewerten; bestehende Chancen unverändert |

Fehlerschleifen: (1) Der Browser-Test fand eine doppelte Deklaration `rebase` in `formguard.js`, die das ganze Skript und damit den Eingabeschutz stillgelegt hätte – jetzt wird die vorhandene Funktion nach außen gegeben, ein Strukturtest prüft das. Lehre: neue Bezeichner in bestehenden Skripten vor dem Einfügen suchen und `node --check` auf jede geänderte Datei anwenden.

**Selbstbewertung 4 von 5.** Abzug: Aufgaben und Paketabgleich hängen noch an der Firma; Chancen-Karten lassen sich in der Pipeline nicht ziehen.

**Entscheid:** M13 ist abgeschlossen. Weiter mit M14 (Briefings je Leistungsbereich).

## Arbeitspaket 19 – Briefing je Chance (2.0.0-dev20)

Auftrag: direkt am nächsten Schritt weiterarbeiten – laut Roadmap M14. Fragen aus dem Onboarding-Leitfaden (Medien, Software) und dem Bewertungsmodell (Analyse), Leistungsbereiche aus dem zentralen Katalog.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 625 Tests bestanden (7 neu in `tests/test_v2_briefing.py`, 2 in `tests/test_tmpclean.py`) |
| Browser-Tests | 16 von 16 (neu `test_briefing_browser.py`: Briefing an der Chance, Antworten speichern, Übernahme ins Angebot; `test_chances_browser.py` wählt die Kopfzeile der Karte eindeutig, `test_akte_tabs_browser.py` wartet jetzt den Start ab – im Gesamtlauf klickte er vorher zu früh, allein lief er grün) |
| Abnahme M14 | Fragen je Leistungsbereich; jede Angebotsannahme stammt aus einer geklärten Angabe oder einer ausdrücklich offenen Voraussetzung; Schnappschuss intern am Angebot |
| Migration | Schema 32 → 33, neue Tabelle und Spalte mit Vorgabewert |

Fehlerschleifen: (1) Gewählte Bereiche erschienen in Klickreihenfolge statt in fester Reihenfolge – jetzt immer wie im Katalog. (2) Die CI-Prüfung `e2e` scheiterte beim Aufräumen von `test_ui_workday.py` („Directory not empty“): Ein Hintergrund- oder Anfrage-Thread legte während des Löschens SQLite-Begleitdateien neu an. Der Test nutzt jetzt die gemeinsame Aufräumhilfe (erst Worker beenden), und die Hilfe wiederholt auch bei diesem Linux-Fehler; ein Test zeigt, dass die alte Hilfe hier scheiterte.

**Selbstbewertung 4 von 5.** Abzug: feste Fragen ohne eigene Ergänzungen; das Briefing blockiert die Freigabe bewusst nicht.

**Entscheid:** Weiter mit M15 (Angebotsrevisionen und Varianten).

## Arbeitspaket 20 – Angebotsrevisionen (2.0.0-dev21)

Auftrag: weiterarbeiten bis zum Nutzungslimit, vorher jeweils einen nachvollziehbaren, abgeschlossenen Schritt sichern. M15 ist deshalb in zwei eigenständig abnehmbare Teile geteilt (Revisionen, dann Optionen/Varianten).

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 629 Tests bestanden (4 neu in `tests/test_v2_revisions.py`) |
| Browser-Tests | 17 von 17 (neu `test_revision_browser.py`: Überarbeiten lädt den Vorgänger, Position entfernen, Grund, Fassung -R2 mit Änderungsliste, alte Fassung „Ersetzt“) |
| Abnahme T11 | Revision zeigt Vorgänger und wesentliche Änderungen; Vorgänger unverändert und ersetzt; angenommener Stand bleibt |
| Migration | Schema 33 → 34, vier Spalten mit Vorgabewerten |

**Selbstbewertung 4 von 5.** Abzug: Optionen und Varianten fehlen noch (Teil 2); bei rekonstruierten Altangeboten können Feinheiten fehlen (dokumentiert).

## Arbeitspaket 21 – Optionale Positionen (2.0.0-dev22)

Zweiter Teil von M15. Statt eines eigenen Variantenmodells (Basis/Standard/Erweitert nebeneinander) gibt es optionale Positionen: Das deckt den häufigen Fall „das könnten wir zusätzlich machen“ ab, ohne eine zweite Kalkulationslogik. Eine gewählte Option wird über eine Revision fest übernommen.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 631 Tests bestanden (2 neu in `tests/test_v2_options.py`) |
| Browser-Tests | 18 von 18 (neu `test_options_browser.py`): Haken „optional“, Vorschau zeigt „nicht im Festpreis“, Summe entspricht den festen Positionen |
| Doppelkalkulation | Festpreis, monatlich, Laufzeit, Zahlungsplan, interne Kosten und Rechnung „voll“ ohne Optionen (Unit-Test) |
| Migration | keine |

**Selbstbewertung 4 von 5.** Abzug: kein Variantenvergleich nebeneinander (bewusst, dokumentiert); die Annahme einer einzelnen Option braucht den Umweg über eine Revision.

## Arbeitspaket 22 – Nachfassen mit Anlass, Frist und Ergebnis (2.0.0-dev23)

M16 auf versendete Angebote begrenzt: Dort hängt am meisten Umsatz, und dort fehlte der Bezug. Nachfassen nach Erstkontakt hat mit Anrufprotokoll und Wiederholversuchen schon einen eigenen Weg.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 638 Tests bestanden (6 neu in `tests/test_v2_followups.py`, 1 neu in `tests/test_release_modules.py`; ein bestehender Test auf den neuen Aufgabentitel angepasst, der Hinweis „zulässigen Weg prüfen“ bleibt im Titel) |
| Browser-Tests | 19 von 19 (neu `test_followup_browser.py`): Frist und Anlass beim Versand, Ergebnis „nicht erreicht“ mit neuer Frist, dann „nicht weiter nachfassen“ |
| Fund beim Testen | Eine ungültige Frist wurde erst nach dem Statuswechsel geprüft; ein zweiter Versuch in derselben Verbindung galt dann als „unverändert“. Prüfung vor jede Änderung gezogen. |
| Doppelung in Heute | Nachfassaufgabe und gleichlautender nächster Schritt der Firma erschienen doppelt – jetzt nur einmal |
| Migration | Schema 34 → 35, fünf Spalten an `tasks` mit Vorgabewerten |
| Release-Paket | Erster Bau ohne das neue, noch nicht committete Modul. Ergänzt; neuer Test verlangt jedes Modul und jede Oberflächendatei im Paket; Paket entpackt und Datenbank daraus angelegt |

**Selbstbewertung 4 von 5.** Abzug: In der allgemeinen Aufgabenliste abgehakte Nachfassaufgaben haben kein Ergebnis (dokumentiert).

## Arbeitspaket 23 – Auftragsübergabe und Abnahme (2.0.0-dev24)

„Schlank“ heißt hier: keine Projektverwaltung, sondern genau die Nachweise, die ein Solo-Auftrag braucht. Dazu gehört, was übergeben wurde, wann und wie, was der Kunde abgenommen hat und was noch offen ist. Am Angebot statt in einem neuen Bereich, weil dort Versand und Zusage schon stehen.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 641 Tests bestanden (3 neu in `tests/test_v2_handover.py`) |
| Browser-Tests | 20 von 20 (neu `test_handover_browser.py`): Liefergegenstände abhaken, Übergabe, Abnahme mit Restpunkt, Protokoll-Download, Restpunkt erledigt → abgenommen |
| Abnahme T12 | bestanden |
| Fund beim Testen | Erwartung im eigenen Test falsch gezählt (fünf statt sechs Verlaufseinträge) – Code war richtig, Test korrigiert |
| Abgrenzung | Abnahmeaufgaben tauchen nicht im Nachfassen auf und lassen sich dort nicht mit einem Ergebnis schließen (Unit-Test) |
| Migration | Schema 35 → 36, zwei neue Tabellen |

**Selbstbewertung 4 von 5.** Abzug: Protokoll nur als Markdown; Restpunkte nach der Abnahme sind bewusst keine Zusatzaufträge (M18 offen).

## Arbeitspaket 24 – Zusatzaufträge (2.0.0-dev25)

Leitfrage aus dem Review: Bleibt der Ursprungsumfang erkennbar? Deshalb ist ein Zusatzauftrag kein geändertes Angebot, sondern ein neues mit festem Bezug. Der angenommene Stand wird nie angefasst. Wiederverwendet wird der ganze Angebotsablauf, damit Freigabe und Nachweise nicht doppelt gebaut werden.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 643 Tests bestanden (2 neu in `tests/test_v2_addenda.py`) |
| Browser-Tests | 21 von 21 (neu `test_addendum_browser.py`): Zusatzauftrag aus dem Auftrag, Leistung, Anlass, -Z1, Auftragsumfang; Auftrag in der Datenbank unverändert |
| Ursprungsumfang | Kundendokument und Auftrag unverändert (Unit- und Browser-Test); Summe zählt nur angenommene Zusatzaufträge, Revisionen nicht doppelt |
| Fund beim Testen | Rückwärtsschrägstrich in einem f-String-Ausdruck hätte unter Python 3.10 nicht kompiliert – vor dem ersten Lauf umgestellt |
| Migration | Schema 36 → 37, zwei Spalten mit Vorgabewerten |

**Selbstbewertung 4 von 5.** Abzug: keine Minderung nach der Zusage; keine gemeinsame Schlussrechnung (dokumentiert).

## Arbeitspaket 25 – Bestandskunden und Betreuung (2.0.0-dev26)

Abnahmekriterium: Betreuung und neue Projekte getrennt. Die eigentliche Lücke war die Abrechnung: Monatsrechnungen hatten keinen Leistungszeitraum, ließen sich beliebig oft erzeugen und es war nicht sichtbar, welcher Monat fehlt. Darum ist die Betreuung über ihre Monate definiert, nicht über ein neues Vertragsmodell.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 646 Tests bestanden (3 neu in `tests/test_v2_care.py`; bestehende Monatsrechnungs-Tests unverändert grün) |
| Browser-Tests | 22 von 22 (neu `test_care_browser.py`): Betreuung und Projekt getrennt, Monatsrechnung für den offenen Monat, Laufzeit beenden, neue Chance |
| Fund beim Testen | Rechnungsentwurf entsteht erst nach dem Wechsel in „Abrechnen“ – Browser-Test wartete zu kurz; Test wartet jetzt auf den Entwurf |
| Migration | Schema 37 → 38, eine neue Tabelle; bestehende Betreuungen beginnen mit dem Zusagedatum |

**Selbstbewertung 4 von 5.** Abzug: ältere Monatsrechnungen ohne Leistungszeitraum werden nicht zugeordnet; keine anteiligen Monate (dokumentiert).

## Arbeitspaket 26 – Zeiten je Leistung (2.0.0-dev27)

Seit dev16 hat jede Position eine Leistungskennung; es fehlte nur die Zuordnung der Ist-Zeit. Lernvorschläge bewusst zurückhaltend: Erst ab drei Stichproben, immer mit Spanne, ohne automatische Änderung des Katalogs. Bei wenigen Aufträgen wäre alles andere Scheingenauigkeit.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 648 Tests bestanden (2 neu in `tests/test_v2_service_times.py`) |
| Browser-Tests | 23 von 23 (neu `test_service_times_browser.py`): Position wählen, Zeit erfassen, Tabelle zeigt Soll/Ist |
| Fund beim Testen | Zweites Angebot derselben Firma braucht nach der Zusage eine eigene bestätigte Chance – Testaufbau angepasst (Verhalten richtig) |
| Migration | Schema 38 → 39, eine Spalte |

**Selbstbewertung 4 von 5.** Abzug: Zuordnung freiwillig, daher anfangs wenig Daten; Wirkung nach Methode (M34) bleibt offen.

## Arbeitspaket 27 – Projektkompass (2.0.0-dev28)

M38 und M39 zusammen, weil der Startstatus genau aus der Material- und Entscheidungsliste folgt. Getrennt wären es zwei Listen für dieselbe Frage: Was fehlt noch, und wer ist dran? Der Status wird berechnet, nicht von Hand gepflegt; nur „gestartet“ setzt du bewusst.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 651 Tests bestanden (3 neu in `tests/test_v2_kickoff.py`) |
| Browser-Tests | 24 von 24 (neu `test_kickoff_browser.py`): „wartet auf Kunde“, Name setzen, Passwort abgelehnt, Punkte erledigen bis „bereit“, Start |
| Abnahme M38/M39 | Vorbelegung, Status, Unabhängigkeit mehrerer Projekte, Verantwortliche/Frist/Auswirkung, keine Zugangsdaten |
| Fund beim Testen | Testaufbau: vor dem ersten Angebot gibt es noch keine Chance; Briefing-Antworten sind eine Liste – Test korrigiert, Code unverändert |
| Migration | Schema 39 → 40, zwei neue Tabellen |

**Selbstbewertung 4 von 5.** Abzug: Briefing-Änderungen nach dem ersten Öffnen kommen nicht nach; Zugangsdaten-Erkennung ist eine Schutzregel, keine Garantie.

## Arbeitspaket 28 – Nachrichtenvorlagen (2.0.0-dev29)

Geprüft mit der Prüfliste `privacy-and-contact-guardrails`:

| Punkt | Ergebnis |
|---|---|
| 1 Sperre | eingehalten – `messages.render` ruft `assert_contact_allowed`; Entwurf läuft über `render` (Test mit gesperrter Firma: keine Vorschau, kein Entwurf) |
| 2 Reimport | nicht betroffen |
| 3 Keine Erlaubnis aus Daten | eingehalten – Vorlagen setzen keine `permission`; Hinweis auf eigene Prüfung werblicher Mails |
| 4 Kein Versand | eingehalten – nur Vorschau, Kopie, Entwurf |
| 5 Personen | eingehalten – keine Person wird angelegt; Anrede nur von Hand, nie aus dem Vornamen |
| 6 Datensparsamkeit | eingehalten – neues Feld `salutation` mit Zweck „Anrede in Nachrichten“; wird mit der Person gelöscht |
| 7 Lesende Auswertungen | nicht betroffen |
| 8 Test | `test_blocked_firm_and_restricted_person` scheitert ohne Sperrprüfung bzw. ohne Prüfung der Personen-Einschränkung |

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 654 Tests bestanden (3 neu in `tests/test_v2_messages.py`) |
| Browser-Tests | 25 von 25 (neu `test_messages_browser.py`): Lücken markiert, Endfassung gesperrt, mit Angebot und Person vollständig, neutrale Anrede, Entwurf gespeichert |
| Fund beim Testen | Hervorhebung fehlender Werte nutzte eine feste Farbe; der Theme-Test (Hell/Dunkel) schlug an – auf die Theme-Variablen umgestellt |
| Migration | Schema 40 → 41, eine Tabelle, fünf Spalten |

**Selbstbewertung 4 von 5.** Abzug: keine Titel in der Anrede; keine bedingten Textbausteine.

## Arbeitspaket 29 – Kundenfähiger Kurzbericht (2.0.0-dev30)

Auswahl statt Export: Der Bericht entsteht aus einzeln angekreuzten, bereits geprüften Befunden. Was intern bleibt, steht als Liste im Modul und ist im Test als „darf nicht vorkommen“ geprüft.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 656 Tests bestanden (2 neu in `tests/test_v2_customer_report.py`) |
| Browser-Tests | 26 von 26 (neu `test_kurzbericht_browser.py`): nur geprüfter Befund wählbar, Vorschau ohne interne Werte, Download |
| Leitplanken | Sperre geprüft (Test mit gesperrter Firma), keine Personen, kein Versand |
| Fund beim Testen | Im eigenen Testaufbau waren Lauf- und Firmen-ID vertauscht (fiel nur wegen gleicher IDs nicht auf) – korrigiert; die Firmenauswahl der Bewertungsansicht wurde nicht befüllt – Modul füllt sie selbst |
| Migration | Schema 41 → 42, eine neue Tabelle |

**Selbstbewertung 4 von 5.** Abzug: keine Screenshots, kein gestaltetes Dokument.

## Arbeitspaket 30 – Abnahmefälle T06 und T15 (2.0.0-dev31)

Nach acht Schemawechseln in Etappe C und D war die wichtigste offene Frage, ob eine Sicherung mit allen neuen Daten vollständig zurückkommt. Beide Fälle sind als Szenario geprüft, ohne Codeänderung.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 658 Tests bestanden (2 neu in `tests/test_scenario_t15_restore.py`) |
| Browser-Tests | 27 von 27 (neu `test_t06_retry_browser.py`) |
| T15 | bestanden: 16 Tabellen vollständig, Abläufe in der Testinstallation funktionieren, Ausgangsinstallation unverändert, Sicherheitskopie in der Testinstallation, ältere Sicherung migriert |
| T06 | bestanden: anderer Zeitpunkt, Frist, nach drei Versuchen Kanalwechsel/Parken |
| Fund beim Testen | Browser-Test klickte den dritten Versuch, bevor die Ansicht nach dem zweiten neu geladen war – Test wartet jetzt auf den gespeicherten Versuch (kein Fehler der Anwendung) |

**Selbstbewertung 5 von 5** für den Umfang dieses Pakets (reine Prüfung, beide Fälle bestanden).

## Arbeitspaket 31 – Abnahmefälle T07, T09, T10, T13 (2.0.0-dev32)

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 662 Tests bestanden (4 neu in `tests/test_scenarios_t07_t13.py`) |
| Browser-Tests | 27 von 27 |
| T07, T09, T10, T13 | bestanden |
| Fund beim Testen | Kundendokument: Beträge im Abschnitt „Festpreis“ mit Dezimalpunkt statt Komma – behoben, Test prüft die Schreibweise. Der eigene Test war anfangs zu streng: „Stundensatz“ ist bei „Leistung nach Aufwand“ eine legitime Kundenangabe, kein interner Wert; die Prüfung interner Felder läuft jetzt über die Schlüssel statt über Teilwörter. |

**Selbstbewertung 5 von 5** für dieses Paket. Bestanden sind T01–T13 und T15; T14 bleibt offen bis M23.

## Arbeitspaket 32 – Befund mit Angebot verbinden (2.0.0-dev33)

Bewusst Hinweis statt Sperre: Ein Angebot ohne Beleg kann richtig sein (z. B. ausdrücklicher Kundenwunsch ohne dokumentierten Bedarf). Wichtig ist, dass die Lücke sichtbar ist und ungeprüfte Vermutungen nie still als Begründung dienen.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 664 Tests bestanden (2 neu in `tests/test_v2_offer_basis.py`) |
| Browser-Tests | 28 von 28 (neu `test_offer_basis_browser.py`): Grundlage, Lücke, offene Hypothese, Hinweis bei der Freigabe |
| Abnahme M32 | jede Position mit Grundlage; offene Hypothesen sichtbar; nichts im Kundendokument |
| Fund beim Testen | Name der fiktiven Testfirma enthielt das geprüfte Wort „Grundlage“ – Testfirma umbenannt. Die neue Box nutzte die Klasse der Fassungen-Übersicht mit; der Revisions-Browsertest fand dadurch zwei Elemente – eigene Klasse vergeben |

**Selbstbewertung 4 von 5.** Abzug: Zuordnung Befund → Leistung nur über die Paketvorlagen.

## Arbeitspaket 33 – Globale Suche (2.0.0-dev34)

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 666 Tests bestanden (2 neu in `tests/test_v2_global_search.py`) |
| Browser-Tests | 29 von 29 (neu `test_search_browser.py`): Strg+K, Escape mit Fokus-Rückgabe, Treffer nach Gruppen, Pfeiltasten mit Umlauf, Enter öffnet das Angebot |
| Leitplanken | Personen nicht durchsuchbar (Test); nur lesend |
| Fund beim Testen | Eigener Fehler: Die neue Testdatei hieß zunächst wie eine bestehende (`test_v2_search.py`, Praxistest-Suche) und hätte sie überschrieben; beim Abgleich der Testzahl bemerkt, Original wiederhergestellt, neue Tests in `test_v2_global_search.py`. Zwei Testerwartungen falsch: Präfix-Treffer stehen bewusst vorn; ein Angebot legt seine Chance an, die mit gefunden wird. Ein langer Befehl wurde von der Sicherheitsprüfung der Umgebung nicht ausgeführt (nicht eindeutig lesbar) – Dateien stattdessen einzeln geschrieben, nichts gelöscht. Der Suchknopf machte die Kopfzeile auf dem Handy (390 px) 2–3 px zu breit; die bestehenden Browser-Tests zur Handyansicht schlugen an – auf schmalen Bildschirmen nur Lupensymbol, engerer Abstand |

**Selbstbewertung 4 von 5.** Abzug: keine Tippfehler-Toleranz; Rechnungstreffer öffnen nur die Liste.

## Arbeitspaket 34 – Gemeinsame Hintergrundaufträge, Teil 1 (2.0.0-dev35)

Die Website-Bewertung ist der Schritt mit den meisten Abrufen und damit den meisten Abbrüchen; der Karriereseiten-Scan hatte dasselbe Muster. Beide folgen jetzt dem Vorbild des Firmen-Berichts (Schritt je Firma, Übernahme älterer Einträge, Wiederholen-Haken). Die Aufrufe `enqueue`/`wait_idle` bzw. `enqueue_scans`/`wait_scans` bleiben gleich, damit Oberfläche und bestehende Tests unverändert funktionieren.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 670 Tests bestanden (4 neu in `tests/test_scenario_t14_resume.py`; bestehende Bewertungs-, Signal- und Auftragstests unverändert grün) |
| Browser-Tests | 29 von 29 |
| T14 | bestanden für die vier Module im Auftragssystem: Neustart im laufenden Schritt, Übernahme älterer Einträge ohne Doppelung, Wiederholen nur des fehlgeschlagenen Schritts |
| Rest | KI-Analyse, Schnellprüfung, öffentliche Ansprechpartner, Impressum-Sammelprüfung, Sammelsuche-Wiederholung – Teil 2 |

**Selbstbewertung 4 von 5.** Abzug: M23 erst zur Hälfte; Fortsetzen heißt „Schritt von vorn“, nicht „an der Stelle weiter“.

## Arbeitspaket 35 – Gemeinsame Hintergrundaufträge, Teil 2 (2.0.0-dev36)

Die drei Läufe hatten dasselbe Muster (`run_job` plus Thread). Ein kleiner gemeinsamer Baustein (`bg_jobs.py`) macht aus jedem Lauf einen Auftrag mit einem Schritt; `run_job` bleibt unverändert, damit die bestehenden Tests und Aufrufer gleich bleiben.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 673 Tests bestanden (3 neu in `tests/test_scenario_t14_runs.py`) |
| Browser-Tests | 29 von 29 |
| T14 | bestanden: alle Recherche-Läufe außer der Impressum-Sammelprüfung setzen nach Neustart fort; die Sammelprüfung pausiert sichtbar und wird von Hand fortgesetzt |
| Fund beim Arbeiten | Die Ansprechpartner-Suche hatte keine Wiederaufnahme und blieb nach einem Absturz dauerhaft auf „läuft“ – behoben |

**Selbstbewertung 4 von 5.** Abzug: Impressum-Sammelprüfung und Einzelquellen-Wiederholung der Sammelsuche laufen noch eigenständig.

## Arbeitspaket 36 – Faustregeln als Hinweis (2.0.0-dev37)

Bewusste Verhaltensänderung nach Review M28: Die vier Regeln zählen etwas (Schriftfamilien, Jahreszahl, Überschriften, Links), das nur lose mit Qualität zusammenhängt. Als Urteil hätten sie die Priorität verzerrt und – über M32 – sogar Angebotspositionen „belegt“. Jetzt sind sie Prüfhinweise. Messbasierte Rubriken bleiben unverändert.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 675 Tests bestanden (2 neu in `tests/test_v2_rubric_hints.py`) |
| Rendering-Tests mit echtem Browser | 14 von 14 (`test_phase2_scoring` mit Chromium, sonst übersprungen) |
| Angepasste Tests | `test_weak_site_flags_measured_issues` und `test_weak_site_is_flagged_from_real_rendering`: die vier Regeln jetzt als Hinweis; der Bereichswert wird gegen die Rechnung geprüft statt gegen eine feste Schwelle |
| Browser-Tests | 29 von 29 |

**Selbstbewertung 4 von 5.** Abzug: Die Schwellen der übrigen Rubriken sind weiterhin Vorgaben ohne Fachreview (M29/M33).

## Arbeitspaket 37 – Angebot mit eigener Adresse (2.0.0-dev38)

Kleiner Schritt aus M07: Seit der globalen Suche (dev34) springt man oft direkt in ein Angebot – ohne Adresse ging dieser Stand beim Neuladen verloren. Die Entscheidung, ob die Firmenakte eine eigene Seite statt eines Dialogs wird, bleibt beim Eigentümer.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 675 Tests bestanden |
| Browser-Tests | 30 von 30 (neu `test_offer_address_browser.py`: Adresse nach dem Öffnen, Neuladen, eingegebene Adresse, Zurück) |
| Fund beim Testen | Während eine eingegebene Adresse noch nachlud, verschluckte ein schneller Klick auf ein anderes Angebot den Verlaufseintrag – die Ausnahme gilt jetzt nur für das gerade wiederhergestellte Angebot. Der Test drückte „Zurück“ anfangs, bevor das Angebot fertig aufgebaut war; er wartet jetzt auf die Adresse |

**Selbstbewertung 4 von 5.** Abzug: Filteradressen weiterer Listen stehen noch aus.

## Arbeitspaket 38 – Sammelprüfung nach Neustart (2.0.0-dev39)

Auf Wunsch des Eigentümers nach Empfehlung umgesetzt: automatisch fortsetzen, aber nur, was beim Neustart wirklich lief; nie im Offline-Modus; sichtbar in „Heute“. Kein Umbau auf das gemeinsame Auftragssystem – die Sammelprüfung hatte schon einen gespeicherten Zustand mit Pause, Fortsetzen und Abbruch.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 678 Tests bestanden (2 neu in `tests/test_v2_batch_resume.py`, 1 neu in `tests/test_tmpclean.py`) |
| Browser-Tests | 30 von 30 |
| CI-Fehler | `unit (windows-latest, Python 3.10)`: Aufräumen scheiterte mit NotADirectoryError (WinError 267) bei gesperrter Datei – Test zeigt, dass der alte Helfer scheiterte |
| Fund beim Testen | Eigener Fehler: Die neue Testklasse erbte zunächst von einer bestehenden; deren Tests liefen dadurch doppelt – jetzt eigener Aufbau |

**Selbstbewertung 5 von 5** für dieses Paket.

## Arbeitspaket 39 – Firmenakte als eigene Seite (2.0.0-dev40)

Variante B auf Entscheidung des Eigentümers. Umsetzung bewusst schmal: dasselbe Element mit Reitern und Eingabeschutz, nur an anderer Stelle und anders dargestellt. So bleiben alle Funktionen und die bestehenden Tests gültig; geändert hat sich nur die Adresse.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 678 Tests bestanden |
| Browser-Tests | 31 von 31 (neu `test_akte_page_browser.py`): Seite statt Fenster, Zurück-Knopf, Browser-Zurück aus einer anderen Ansicht, Handyansicht ohne seitliches Scrollen; `test_navigation_browser.py` auf die neue Adresse angepasst |
| Fund beim Arbeiten | Ohne die Listenfilter in der Akten-Adresse ging beim Neuladen die gefilterte Liste verloren – Filter wandern jetzt mit |

**Selbstbewertung 4 von 5.** Abzug: keine zwei Akten nebeneinander.

## Arbeitspaket 40 – Kalender-Abo (2.0.0-dev41)

M24 nach Empfehlung, Stufe 1 von 3. Ein Abo braucht keine Zugangsdaten und funktioniert mit jedem Kalenderprogramm; die Grenze (nicht aus dem Internet erreichbar) ist im Abschnitt selbst erklärt.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 680 Tests bestanden (2 neu in `tests/test_v2_calendar_feed.py`) |
| Browser-Tests | 32 von 32 (neu `test_calendar_browser.py`): Abo einschalten, Adresse liefert Termine, Ausschalten macht sie ungültig |
| Wackeliger Test behoben | `test_kickoff_browser.py` füllte unter Last ein Eingabefeld, das sich gerade neu aufbaute, und wartete auf eine Meldung, die schnell überschrieben wurde – Eintragen und Klick jetzt in einem Schritt, Meldungen werden mitgeschrieben (Anwendung unverändert) |
| Datenschutz | Notizen nicht im Kalender (Test); Zugriff nur mit Schlüssel, Verwaltung nur mit Login (Test) |

**Selbstbewertung 4 von 5.** Abzug: nur lesend – der Abgleich folgt mit CalDAV.

## Noch nicht erstellte Dokumente aus dem Auftrag

`SAAS_LAUNCH_PLAN.md`, `DATA_SOURCE_MATRIX.md`, `PRODUCT_ONBOARDING.md`, `SECURITY_PRIVACY_CHECKLIST.md` gehören zu späteren Sprints und sind bewusst noch nicht angelegt. Die Roadmap ist mit 2.0.0-dev11 neu gefasst.

## Arbeitspaket 41 – Kalender-Abgleich über CalDAV (2.0.0-dev42)

M24 nach Empfehlung, Stufe 2 von 3. Bewusst sparsam in Gegenrichtung: aus dem Kalender kommen nur belegte Zeiten, keine Inhalte – das genügt für Konfliktwarnung und freie Vorschläge und hält fremde Daten aus SignalDesk heraus.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 686 Tests bestanden (6 neu in `tests/test_v2_caldav.py`, gegen einen nachgebauten CalDAV-Server auf 127.0.0.1) |
| Browser-Tests | 33 von 33 (neu `test_caldav_browser.py`): Zugang eintragen, Verbindung prüfen, abgleichen, Konfliktwarnung |
| Abgleich | Termin geschrieben, zweiter Lauf überträgt nichts, Änderung wird übertragen, Löschung entfernt nur den eigenen Eintrag; fremder Eintrag unverändert (Test) |
| Datenschutz | keine Notizen im Kalender; Titel fremder Einträge nicht in SignalDesk; Passwort weder in Datenbank noch WAL noch Antwort an die Oberfläche (Test) |
| Grenzen | HTTPS-Pflicht außer auf diesem Rechner, Offline-Modus sendet nichts, falsches Passwort mit klarer Meldung (Test) |

**Selbstbewertung 4 von 5.** Abzug: an keinem echten Anbieter gemessen, Abgleich nur auf Knopfdruck, keine automatische Kalendersuche im Konto (in `docs/EINSCHRAENKUNGEN.md` beschrieben).

## Arbeitspaket 42 – Entwürfe ins Postfach über IMAP (2.0.0-dev43)

M24 nach Empfehlung, Stufe 3 von 3. Bisher galt „keine Verbindung zu Maildiensten“; der Eigentümer hat das Ablegen von Entwürfen freigegeben. Die Leitplanke (`.claude/skills/privacy-and-contact-guardrails`) nennt jetzt diese eine Ausnahme, und ein Test hält sie eng: kein SMTP, IMAP nur in `imap_drafts.py`, dort nur Ordnerliste und APPEND.

| Prüfung | Ergebnis |
|---|---|
| Regression unter Python 3.13 und 3.10 | je 691 Tests bestanden (5 neu in `tests/test_v2_imap_drafts.py`, gegen einen nachgebauten IMAP-Server auf 127.0.0.1) |
| Browser-Tests | 34 von 34 (neu `test_imap_browser.py`): Postfach eintragen, Ordner finden, Entwurf ablegen |
| Kein Versand | kein `smtplib` im Programm; nur CAPABILITY, LOGIN, LIST, APPEND, LOGOUT am Server (Test) |
| Sperren | gesperrte Firma und Person mit „keine E-Mail“: keine Verbindung, nichts abgelegt (Test) |
| Datenschutz | Passwort weder in Datenbank noch Antwort an die Oberfläche; Empfänger nur geschäftliche Firmenadresse (Test) |

**Selbstbewertung 4 von 5.** Abzug: an keinem echten Anbieter gemessen; nur SSL auf Port 993, kein STARTTLS (in `docs/EINSCHRAENKUNGEN.md` beschrieben).

**Nachtrag (CI Windows, Python 3.13 auf dev40):** `test_malformed_requests_never_500` brach mit WinError 10048 ab – der Test öffnet je Anfrage eine neue Verbindung (Routen × 4 Methoden × 7 Inhalte), und Windows hält geschlossene Client-Ports eine Weile belegt. Mit jeder neuen Route wurde das knapper. Der Test-Helfer wartet jetzt kurz und versucht es erneut, nur bei genau diesem Fehler; andere Fehler gehen unverändert durch (lokal nachgewiesen). Die Prüfung selbst ist unverändert, Anwendung unverändert.

## Arbeitspaket 43 – Befund Stuttgart-Auszug (2.0.0-dev44)

Der Eigentümer hat den Stuttgart-Auszug (222 MB) eingelesen: viele Betriebe im Bestand, aber nur 5 neue Treffer, „viel ausgefiltert“, die Website-Suche fand nichts. Gesucht wurde in ganz Stuttgart mit Branchen und **ohne** „auch Betriebe ohne Rechtsform“.

Ursachen (aus dem Code nachvollzogen, ohne den echten Auszug – der ist nicht in dieser Umgebung):
1. Ohne den Haken fallen alle Betriebe ohne Rechtsform im Namen heraus – im Handwerk die meisten (schon im Praxistest 70191: 3 von 4).
2. Die Website-Suche läuft nur für die übernommenen neuen Treffer – hier also für 5.
3. Die Domain-Vorschläge ließen den Ort weg, und der Namensvergleich mit dem Impressum scheiterte schon an anderer Wortreihenfolge.

| Prüfung | Ergebnis |
|---|---|
| Neue Tests | `tests/test_v2_osm_findings.py` (4): Gründe gezählt und Summe stimmt, Domains mit Ort, Wortreihenfolge passt, fremde Namen und andere PLZ passen weiterhin nicht |
| Browser | neu `test_osm_filter_reasons_browser.py`: Gründe in der Ergebniszeile, Hinweis zum Haken |
| Regression | je 695 Tests unter Python 3.13 und 3.10, 35 von 35 Browser-Tests |
| Wackeliger Test behoben | `test_formguard_browser.py` scheiterte etwa jedes dritte Mal: Der Klick auf „Firmen“ kam manchmal vor dem Fertigladen an, und die fokussierte Zeile konnte durch einen zweiten Listenaufbau ersetzt werden. Der Test öffnet die Liste jetzt über ihre Adresse und wartet auf den Fokus – danach 10 von 10 Läufen grün (Anwendung unverändert) |
| Offen | Wirkung am echten Auszug noch nicht gemessen; die Messung ist M21 |

**Selbstbewertung 3 von 5.** Die Ursachen sind belegt und behoben bzw. sichtbar, aber nicht an deinen Daten gemessen.

## Arbeitspaket 44 – Recherchepilot (2.0.0-dev45)

M21 nach Entscheidung „von Hand prüfen“. Das Werkzeug misst Genauigkeit an echten Treffern; die eigentliche Messung macht der Eigentümer am Stuttgart-Auszug.

| Prüfung | Ergebnis |
|---|---|
| Neue Tests | `tests/test_v2_pilot.py` (3): Stichprobe ohne Dubletten und je Quelle, Stand beim Ziehen bleibt, Quoten nur aus eindeutigen Angaben (nachgerechnet), ungültige Angaben abgelehnt, CSV und Löschen |
| Browser | neu `test_pilot_browser.py`: ziehen, bewerten, Quoten aktualisieren sich, „kein Zielbetrieb“ blendet Fragen aus, Smartphone-Breite ohne waagerechtes Scrollen; Bildschirmfoto selbst angesehen |
| Regression | je 698 Tests unter Python 3.13 und 3.10, 36 von 36 Browser-Tests |
| Grenze | misst nur übernommene Treffer, nicht die verpassten (beschrieben) |

**Selbstbewertung 4 von 5.** Abzug: Die Messung selbst steht noch aus.

## Arbeitspaket 45 – Fachreview und Kalibrierung (2.0.0-dev46)

M29 und M33 nach Entscheidung „direkt in der App“. Das Review hängt an einer bestimmten Bewertung und Version, damit Übereinstimmungen nicht über Regeländerungen hinweg vermischt werden.

| Prüfung | Ergebnis |
|---|---|
| Neue Tests | `tests/test_v2_expert_review.py` (3): Übernahme der Rubriken, sofortiges Speichern (über eine zweite Verbindung geprüft), fehlende Angaben, Abschluss, Unveränderlichkeit; Kalibrierung nur aus abgeschlossenen Reviews, nachgerechnet; Gewichte unverändert |
| Browser | neu `test_fachreview_browser.py`: Review anlegen, Rubriken abwählen und beurteilen, nach Neuladen noch da, abschließen, Kalibrierung zeigt 100 % / 0 %; Bildschirmfotos Desktop und Smartphone selbst angesehen |
| Regression | je 701 Tests unter Python 3.13 und 3.10, 37 von 37 Browser-Tests |
| Gefunden und behoben | Speichern beim Verlassen eines Feldes baute die Liste neu und nahm den Fokus aus dem nächsten Feld – Fokus wird jetzt zurückgesetzt |

**Selbstbewertung 4 von 5.** Abzug: Vergleich mehrerer Prüfer untereinander fehlt noch (M33 teilweise).

## Arbeitspaket 46 – Erlebnisstudien und „Was du lernst“ (2.0.0-dev47)

M30 und M34 nach Entscheidung „beides“. Kern von M30 ist die Trennung echter Angaben von allem anderen: ohne Bestätigung zählt eine Sitzung nicht, und es gibt keinen Weg, Antworten erzeugen zu lassen.

| Prüfung | Ergebnis |
|---|---|
| Neue Tests | `tests/test_v2_studies_learning.py` (5): nur bestätigte Sitzungen zählen (Quoten, Median, Antworten nachgerechnet), Kürzel statt Namen, E-Mail/Telefon abgelehnt, Fragen ohne Aufgabenergebnis, fremde Aufgaben abgelehnt, abgeschlossene Studie unveränderlich, Vorher/Nachher; Aufwand je Projektart erst ab 3 Aufträgen, Methoden, Vorher/Nachher-Paare |
| Browser | neu `test_studies_browser.py`: Studie anlegen, Sitzung erfassen, erst nach Bestätigung 50 %, Antwort mit Kürzel, „Was du lernst“ mit Grenzen, Smartphone-Breite ohne waagerechtes Scrollen |
| Regression | je 706 Tests unter Python 3.13 und 3.10, 38 von 38 Browser-Tests |
| Gefunden und behoben | Der neue Browser-Test las „Was du lernst“ einmal zu früh (alter Stand vom ersten Öffnen); er wartet jetzt auf den neuen Inhalt – 6 von 6 Läufen grün (Anwendung unverändert) |

**Selbstbewertung 4 von 5.** Abzug: ohne echte Studien und Aufträge noch ohne Aussage; die Bestätigung echter Angaben ist eine Zusage, keine technische Prüfung (beschrieben).

## Arbeitspaket 47 – Budget-Aufteilung über den Auftragsdienst (2.0.0-dev48)

Befund aus dem Bildschirmfoto des Eigentümers: GLEIF 300 von 300, alle anderen Quellen übersprungen. Die in dev6 eingeführte faire Aufteilung wirkte nur, wenn alle Quellen in einem Aufruf liefen; seit v1.16 ruft der Auftragsdienst je Quelle einzeln auf. Rückfall, den kein Test sah, weil die Prüfung den Auftragsdienst umging.

| Prüfung | Ergebnis |
|---|---|
| Nachgestellt | neuer Test `tests/test_v2_budget_jobs.py` über den Auftragsdienst: vor der Korrektur „OpenStreetMap übersprungen – Budget von 4 neuen Firmen erreicht“, danach grün |
| Auch geprüft | ungenutzter Anteil einer ausgefallenen Quelle geht an die nächste; Wiederholung einer einzelnen fehlgeschlagenen Quelle bekommt den ganzen Rest |
| Regression | je 708 Tests unter Python 3.13 und 3.10, 38 von 38 Browser-Tests |
| Lehre | Prüfungen müssen denselben Weg nehmen wie die Anwendung (hier: Auftragsdienst statt Direktaufruf) |

**Selbstbewertung 4 von 5.** Ursache belegt und behoben; die Wirkung auf die Website-Quote am echten Auszug misst erst die nächste Suche des Eigentümers.

## Arbeitspaket 48 – Baukasten und mobile Navigation (2.0.0-dev49)

Schritt 1 der Etappe „Visuelle Konsolidierung und Aufgabenführung“. Blocker aus der UX-Durchsicht: bei 390 px Breite war keiner der sechs Bereiche außer dem aktuellen erreichbar, weil die Seitenleiste unter 521 px ausgeblendet ist. Dazu der Baukasten aus dem abgestimmten Prototyp als gemeinsame CSS-Grundlage – nur bereitgestellt, noch keine Ansicht umgebaut.

| Prüfung | Ergebnis |
|---|---|
| Neue Tests | `tests/test_v2_ui_baukasten.py` (6): Maße im Grundblock und nur einmal definiert, alle Bausteinklassen vorhanden und mit Präfix `ui-`, neue Regeln ohne feste Farben und nur mit definierten Variablen, Dokument nennt die sieben Bausteine und Messwerte, Menü-Knopf mit `aria-controls`/`aria-expanded`, keine Inline-Handler, Dokument im Release |
| Browser | neu `test_mobile_nav_browser.py`: 390 × 844 – Knopf sichtbar, kein waagerechtes Scrollen, Öffnen zeigt sechs Bereiche mit Markierung und Fokus in der Schublade, „Angebote“ wechselt Adresse und schließt, Escape schließt mit Fokus auf dem Knopf, Hintergrund und „Schließen“ schließen, Zurück im Browser unverändert; 1280 × 720 – Knopf unsichtbar, Seitenleiste 238 px wie bisher; keine Seitenfehler, keine Abrufe nach außen |
| Selbst angesehen | Bildschirmfotos 390 px (zu, offen) in Klassisch hell und dunkel, Schiefer dunkel, Kontrast dunkel, Sand hell; 1280 px vor und nach der Änderung pixelweise verglichen (nur Subpixel-Abweichung im Datumsfeld) |
| Regression | je 714 Tests unter Python 3.13 und 3.10 (übersprungen wie bisher 4 bzw. 6), 39 von 39 Browser-Tests |
| Gefunden und behoben | Beim Einfügen der Maße in den Theme-Grundblock fehlte nach `--card-shadow` das Semikolon – der Schatten wäre ungültig geworden; der Darstellungs-Test hat es gemeldet. Der Test „Dunkelmodus setzt jede Farbrolle“ nimmt die neun Maßvariablen jetzt ausdrücklich aus (sie sind keine Farben) |

**Selbstbewertung 4 von 5.** Abzug: nur in Chromium geprüft, nicht auf echten Geräten; der Baukasten ist bis Schritt 2 ungenutzt, seine Wirkung auf die Messwerte des Zielbilds ist also noch nicht belegt.

## Arbeitspaket 49 – Firmen und Heute auf dem Baukasten (2.0.0-dev50)

Schritt 2 der Etappe E. Grundsatz „keine Funktion entfällt“: Jede verschobene Funktion steht mit altem Ort, neuem Ort und Prüffall in [UI_BAUKASTEN.md](UI_BAUKASTEN.md) („Was wohin zog“). Datenmodell, Prioritätsregeln von „Heute“ und Schnittstellen unverändert; geändert wurden nur drei Anzeigetexte des Servers („Lead öffnen“ → „Firma öffnen“, „Leads, Pipeline …“ → „Firmen, Pipeline …“).

| Prüfung | Ergebnis |
|---|---|
| Abnahmemaße (1280 × 720, 9 Firmen) | Firmen: erste Zeile 221 px (vorher 574, Ziel ≤ 280), 8 Zeilen ganz sichtbar (vorher 2, Ziel ≥ 7), Zeile 56 px, Schrift 14 px (vorher 12); Heute: „Als Nächstes“ bei 184 px (vorher 342, Ziel ≤ 200) |
| Neuer Browser-Test | `test_ui_firmen_heute_browser.py`: Maße, je genau eine sichtbare Hauptaktion, „Neue Firma“ per Knopf und Strg+K, Filter-/Spalten-/Weitere-Menü, Zeile → Akte → Zurück mit Filter, Enter, Klappzeilen mit Kurzstand, „Erledigt“ ohne Akte, Darstellung, 390 × 844 ohne waagerechtes Scrollen (auch mit offenen Menüs), keine Seitenfehler, keine Abrufe nach außen |
| Angepasste Erwartungen | `test_focus_leadlist_browser` (Zeile statt Knopf öffnet; Erste Schritte, „Ansicht speichern“/Löschen und Spalten erst aufklappen), `test_formguard_browser` (Spalten aufklappen), `test_reach_browser`, `test_postcalc_browser` (Klappzeilen aufklappen), `test_appearance_browser` (Hell/Dunkel über Einstellungen), `test_v2_appearance` (kein `modeToggle` mehr; `--ui-cols` als Maßvariable), `test_v2_focus` (neue Markierung der Klappzeile), `test_v2_ui_baukasten` (neue Klassen, Rahmen-Abschnitt ohne feste Farben) – keine Prüfung abgeschwächt |
| Selbst angesehen | Firmen und Heute vorher/nachher in Klassisch hell, Schiefer dunkel, Kontrast (1280 × 720) und 390 × 844; offene Menüs und Klappzeilen; Vergleich mit dem Zielbild |
| Regression | je 714 Tests unter Python 3.13 und 3.10 (übersprungen wie bisher 4 bzw. 6), Browser 40 von 40 in zwei Läufen hintereinander |
| Gefunden und behoben | Das Filter-Menü ragte bei 390 px links aus dem Fenster (−27 px), weil es nur rechtsbündig ausweichen konnte; es wird jetzt in das Fenster geschoben. Die Statuszeile hatte den Standardabstand eines Absatzes (Liste bei 194 statt 184 px). Die Akte wurde hinter der Reiterleiste eingehängt, die jetzt in der Kopfzeile steht – sie folgt nun auf die Kopfzeile |

**Selbstbewertung 4 von 5.** Abzug: „Erledigt“ gibt es nur für Aufgaben und Rückrufe (für nächste Schritte einer Firma fehlt ein fachliches „erledigt“ – bewusst nicht erfunden); schmal zeigen die Listen nur Was · Fällig · ›; nur in Chromium geprüft; die Akte zeigt beim Anlegen noch „Neuer Lead“.

## Arbeitspaket 50 – Finden auf dem Baukasten (2.0.0-dev51)

Schritt 3 der Etappe E. Grundsatz „keine Funktion entfällt“: jede verschobene Funktion mit altem Ort, neuem Ort und Prüffall in [UI_BAUKASTEN.md](UI_BAUKASTEN.md) („Was wohin zog (Schritt 3)“). Server, Datenmodell und Suchlogik unverändert; die Voreinstellungen setzen nur vorhandene Formularfelder; geändert wurden zwei Hinweistexte des Servers (Ort von „OpenStreetMap nutzbar machen“).

| Prüfung | Ergebnis |
|---|---|
| Abnahmemaße (1280 × 720, 11 Treffer) | Neue Suche: „Suche starten“ bei 78 px (vorher 1.455, Ziel ≤ 140); Ort, Umkreis, Branchen enden bei 260 px, „Wen suchst du?“ bei 336 px (Ziel ≤ 720). Sichten: erste Trefferzeile 221 px (vorher 2.124, Ziel ≤ 280), 8 Zeilen ganz sichtbar (vorher 0, Ziel ≥ 7), Zeile 56 px (vorher 117) |
| Neuer Browser-Test | `test_ui_finden_browser.py`: Einstieg nach offenen Treffern (beide Fälle), vier Reiter, alle acht Adressen mit richtigem Reiter und Analysen-Reiterzeile, Abnahmemaße, Spalten und Website-Pillen, Übernehmen/Verwerfen/Website bestätigen/Enter, Filter- und Auswahl-Menü, Branchen als Marken, jede Voreinstellung über `swFormParams()` (= gesendete Parameter), Handänderung → „Eigene Auswahl“, gemerkt über Suchprofil und letzte Suche, Kurzstand und Felder der Klappzeilen, Datenquellen mit Einlesen der Beispiel-PBF und Offline-Suche, Stichprobe unter Datenpflege, Import, je eine Hauptaktion, 390 × 844 ohne waagerechtes Scrollen, keine Seitenfehler, keine Abrufe nach außen |
| Angepasste Erwartungen | `test_navigation_browser` (Reiter von Analysen zählen mit), `test_osm_local_browser` und `test_osm_filter_reasons_browser` (Datei einlesen unter Einstellungen → Datenquellen; Quellen/Optionen aufklappen; Treffer unter Sichten; „Alle Treffer übernehmen“ unter „Auswahl ▾“), `test_pilot_browser` (Datenpflege), `test_ui_workday` (mit offenen Treffern öffnet „Finden“ Sichten – zusätzlich geprüft; Formular unter „Neue Suche“, Klappzeilen aufklappen, Suchlauf-Filter unter „Filter ▾“; Handyprüfung um „sichten“ erweitert) – keine Prüfung abgeschwächt |
| Sporadischer Fehler | `test_studies_browser` scheiterte im ersten Gesamtlauf einmal („Antworten (0)“). Ursache: `wait_for_load_state('networkidle')` kehrt sofort zurück, wenn der Zustand schon einmal erreicht war; das Neuzeichnen nach der zweiten Auswahl konnte die gerade getippte Antwort ersetzen. Der Test wartet jetzt auf das Neuzeichnen und prüft die Antwort vor dem Bestätigen. Einzeln war der Fehler nicht nachzustellen (5 von 5 grün) – die Ursache ist aus dem Ablauf abgeleitet, nicht beobachtet |
| Selbst angesehen | Sichten (auch aufgeklappt), Neue Suche, Analysen, Einstellungen → Datenquellen, Datenpflege vorher/nachher in Klassisch hell und Schiefer dunkel (1280 × 720) sowie Sichten/Neue Suche bei 390 × 844; Vergleich mit dem Zielbild |
| Regression | je 714 Tests unter Python 3.13 und 3.10 (übersprungen wie bisher 4 bzw. 6), Browser 41 von 41 in zwei Läufen hintereinander |
| Gefunden und behoben | Das Filter-Menü blieb nach einer Auswahl offen und verdeckte die erste Zeile (so gewollt: Auswahllisten schließen ein Menü nicht) – der angepasste Test schließt es mit Escape wie ein Mensch. Der Sprung von Einstellungen zurück nach „Neue Suche“ ging nicht über die Reiter, weil die Reiter von Finden dort ausgeblendet sind – über die Seitenleiste. Entfernungen standen als „4 km“ statt „4,0 km“ |

**Selbstbewertung 4 von 5.** Abzug: die Analysen-Unteransichten, Import und Datenquellen stehen noch im alten Aufbau (nur Reiterzeile bzw. neuer Abschnitt); „Spalten ▾“ aus dem Zielbild fehlt; die Ursache des sporadischen Studien-Fehlers ist abgeleitet, nicht nachgestellt; nur in Chromium geprüft.

## Arbeitspaket 51 – Angebote auf dem Baukasten (2.0.0-dev52)

Schritt 4 der Etappe E. Grundsatz „keine Funktion entfällt“: jede verschobene Funktion mit altem Ort, neuem Ort und Prüffall in [UI_BAUKASTEN.md](UI_BAUKASTEN.md) („Was wohin zog (Schritt 4)“). Fachliche Regeln, Server und Datenmodell unverändert; neu ist `angebote.js` (Liste, Editor, Arbeitsplatz, Aufträge), alle Arbeitsschritte kommen weiter aus `offerflow.js`. Geändert ein Hinweistext des Servers (Ort der Nachkalkulation).

| Prüfung | Ergebnis |
|---|---|
| Abnahmemaße (1280 × 720, 5 Angebote) | Liste: erste Zeile 221 px (vorher 2.221, Ziel ≤ 280), Seite 720 statt 3.550 px. Geöffnetes Angebot: Titel 82 px, Reiter 132 px, erste Position 221 px (Ziel ≤ 260), eine Hauptaktion im Kopf. 390 × 844: erste Zeile 330 px (vorher 4.144), kein waagerechtes Scrollen |
| Neuer Browser-Test | `test_ui_angebote_browser.py`: Abnahmemaße, Spalten, Status und nächster Schritt (Freigabe, Nachfassen mit Anlass, Kick-off), Ansichten/Suche/Filter, drei Reiter mit Adressen, Aufträge & Betreuung mit Kick-off, Nachkalkulation und Bestand, Auswertung, Editor über „＋ Neues Angebot“ → Speichern → Angebot, vier Reiter und Kontextspalte, genau eine Hauptaktion durch Entwurf → freigegeben → gesendet → angenommen → Projektstart (Hauptaktion gibt nichts frei), Verlauf, Neuladen, Enter, Zurück, 390 × 844, keine Seitenfehler, keine Abrufe nach außen |
| Fehlerbehebung Studien (E) | Ursache: `save()` zeichnete nach jeder Antwort die ganze Studie neu; Text in anderen Feldern ging verloren, der Fokus ebenso. Gleiches Muster in Fachreview und Stichprobe. Neuer Test `test_keep_input_browser.py` hält die Speicher-Antwort per `page.route` zurück, tippt im anderen Feld, gibt frei und tippt weiter: **vor der Korrektur 3 von 3 rot in zwei Läufen** (Studie „Kontakt war im Fu“, Fachreview „ßbereich versteckt“, Stichprobe „https://maler-“ statt des ganzen Textes), **nach der Korrektur 3 von 3 grün in drei Läufen**. Korrektur: `uiKeep` (Eingaben und Fokus über das Neuzeichnen retten, beim Verlassen speichern) und `uiSerial` (Speichern der Reihe nach) in `uikit.js` |
| Angepasste Erwartungen | `test_briefing_browser`, `test_catalog_browser`, `test_chances_browser`, `test_options_browser` (zuerst „＋ Neues Angebot“), `test_care_browser`, `test_service_times_browser` (`#/angebote/auftraege`), `test_postcalc_browser` (Reiter „Aufträge & Betreuung“), `test_studies_browser` (`#/angebote/auswertung`), `test_revision_browser` (Fassungen im Reiter „Verlauf“; alte Fassung über „← Angebote“ öffnen), `test_offer_address_browser` („← Angebote“ statt Liste unter dem Angebot; „Zurück“ führt jetzt erst zur Liste, dann zum vorherigen Angebot – zusätzlich geprüft), `test_ui_firmen_heute_browser` (Bereich ohne Reiter ist jetzt „Abrechnen“) – keine Prüfung abgeschwächt |
| Gefunden und behoben | Ein verspätetes „Angebot öffnen“ (aus der Chance) holte nach einem Seitenwechsel die Angebote wieder nach vorn – jetzt wechselt nur, wer öffnet. Nach dem Speichern aus dem Editor stand `?neu=1&angebot=…` in der Adresse. Spaltenbreiten zunächst über `--ui-cols` gesetzt – der Baukasten-Test verlangt diese Variable nur einmal; jetzt als eigene Spaltenregel |
| Selbst angesehen | Liste, neues Angebot, geöffnetes Angebot (Entwurf, gesendet, angenommen), Aufträge & Betreuung, Auswertung bei 1280 × 720 in Klassisch hell und Schiefer dunkel, Liste und Angebot bei 390 × 844, vorher/nachher; Vergleich mit dem Zielbild |
| Regression | Unit 714 Tests (4 übersprungen) (Python 3.13) und 714 Tests (6 übersprungen) (Python 3.10), Browser 45 von 45 und 45 von 45 in zwei Läufen hintereinander |

**Selbstbewertung 4 von 5.** Abzug: die Arbeitsschritte, der Editor und die Karten der Nachkalkulation stehen noch in ihren alten Bausteinen (nur eingebettet); die Hauptaktion springt nur zum Schritt; „Spalten ▾“ aus dem Zielbild fehlt; „Fällig“ für angenommene Aufträge bleibt leer, weil der Kick-off keine eigene Frist hat; nur in Chromium geprüft.

**Nachtrag bei der Durchsicht (dev52):** `test_t06_retry_browser.py` scheiterte einmal im Gesamtlauf (dritter Anrufversuch nicht gespeichert). Ursache: Nach jedem Speichern baut „Kontakt & Termine“ die Firmenauswahl neu auf; der Test wartete darauf nur nach dem ersten Versuch und startete den dritten mitten in den Neuaufbau. Außerdem lief die Warteschleife bei Misserfolg still weiter. Der Test wartet jetzt nach jedem Versuch auf den sichtbaren neuen Stand und scheitert sofort mit klarer Meldung. Danach 6 von 6 Einzelläufen und der Gesamtlauf (45 von 45) grün. Anwendung unverändert.

## Arbeitspaket 52 – Einstellungen und Abrechnen auf dem Baukasten (2.0.0-dev53)

Schritt 5 der Etappe E. Grundsatz „keine Funktion entfällt“: jeder Block der langen Einstellungsseite und jede Funktion der Buchhaltung mit altem Ort, neuem Ort und Prüffall in [UI_BAUKASTEN.md](UI_BAUKASTEN.md) („Was wohin zog (Schritt 5)“). Server, Datenmodell und Buchhaltungsregeln unverändert; neu ist `einstellungen.js` (Abschnitte, Kurzstand, Suche, Eingabeschutz), `accounting.js` hat statt fünf innerer Reiter vier Ansichten. Geändert drei Hinweistexte des Servers („Daten & Zugang“ → „Sicherung & Zugang“).

| Prüfung | Ergebnis |
|---|---|
| Abnahmemaße (1280 × 720) | Einstellungen: Abschnittsliste und Inhalt ab 184 px (vorher erster Block bei 377 px, Ziel ≤ 200); Seite 13.728 px → je Abschnitt 1.026–2.847 px. Abrechnen mit 4 Rechnungen: erste Zeile 221 px (vorher 436 px nach Wechsel auf den inneren Reiter, Ziel ≤ 280), Zeile 56 px. 390 × 844: erste Rechnungszeile 374 px (vorher 646), kein waagerechtes Scrollen in allen Abschnitten und Reitern |
| Neuer Browser-Test | `test_ui_einstellungen_abrechnen_browser.py`: Abnahmemaße, neun Abschnitte über Adresse und Liste, 17 bisherige Sprungziele, Verweise aus Angeboten, Finden, „Heute“ (`goAction`) und Abrechnen, zuletzt benutzter Abschnitt (auch nach Neuladen), Kurzstand mit Warnungen (fehlende Pflichtangabe, keine Sicherung), Eingabeschutz (Weiter bearbeiten, Verwerfen, Speichern; auch bei „Zurück“), Suche mit Enter, vier Reiter mit Adressen, Liste mit nächstem Schritt aus vorhandenen Daten, Ansichten/Suche/Filter, geöffnete Rechnung mit genau einer Hauptaktion, Enter öffnet den Entwurf, „＋ Neue Rechnung“ → Editor, Stammdaten-Warnung → Meine Firma → ergänzen → Warnung weg, 390 × 844, keine Seitenfehler, keine Abrufe nach außen |
| Angepasste Erwartungen | `test_appearance_browser`, `test_ui_firmen_heute_browser` (Abschnitt „Darstellung“ zuerst öffnen; Bereich ohne Reiter ist jetzt Einstellungen, Abrechnen hat Reiter), `test_service_profile_browser` (Leistungsprofil unter „Leistungen & Preise“), `test_assessment_browser` („Zielkunden“), `test_reach_browser` („Deine Zeiten“ unter „Kalender & Postfach“), `test_ui_workday` („Sicherung & Zugang“), `test_catalog_browser` (Vorlagen und Katalog sind Klappzeilen – erst aufklappen), `test_navigation_browser` (KI-Studio und Hilfe in der Abschnittsliste statt als Reiter; „preise“ wird nicht mehr angescrollt, sondern steht als Abschnitt bei ≤ 200 px), Unit `test_v2_navigation` (Einstellungen haben statt Reitern eine Abschnittsliste – zusätzlich geprüft: 7 Abschnitte und die Wege zu KI-Studio und Hilfe), Unit `test_v2_appearance` (`--list` ist ein Maß, keine Farbe) – keine Prüfung abgeschwächt oder übersprungen |
| Gefunden und behoben | Nach dem Editor führte `#/abrechnen` per Adresse nicht zur Liste zurück (Editor blieb stehen) – die Adresse zeigt jetzt die Liste. Die 240-px-Liste schnitt Kurzstände ab – Name und Kurzstand jetzt zweizeilig, lange Pflichtangaben gekürzt (vollständig im Tooltip und im Abschnitt). Zwei grüne Knöpfe in der geöffneten Rechnung („Drucken / PDF“ und „Zahlung erfassen“) – „Zahlung erfassen“ ist jetzt Nebenaktion. „Leistungen & Preise“ war mit offenem Katalog 10.850 px lang – Vorlagen und Katalog als Klappzeilen, jetzt 1.751 px. Kalender und Zeiten nebeneinander waren zu eng – wieder untereinander. Zwei sporadische Browser-Fehler in den Zwischenläufen: (1) `test_ui_angebote_browser` – nach „← Angebote“ zeichnet die Liste bis zu dreimal neu (sofort, nach dem Laden, nach Freigabe-/Nachfass-Daten); eine per Tastatur fokussierte Zeile verlor dabei den Fokus, Enter ging ins Leere. Ursache in der Anwendung (dev52), behoben: die Liste gibt den Fokus nach dem Neuzeichnen an dieselbe Zeile zurück (ebenso die neue Rechnungsliste). (2) neuer Test – maß die Zeilenhöhe über einen Locator, während die Liste neu zeichnete; misst jetzt im Browser in einem Schritt. Danach je 3 von 3 Einzelläufen grün |
| Selbst angesehen | Einstellungen (Meine Firma, Leistungen & Preise, Zielkunden, Kalender, Datenquellen, Sicherung, KI-Werkzeuge, Hilfe), Abrechnen (Rechnungen, Ausgaben, Auswertung, Steuer & Export, Editor, geöffnete Rechnung) bei 1280 × 720 in Klassisch hell und Schiefer dunkel, Einstellungen (Liste, Abschnitt) und Abrechnen bei 390 × 844, vorher/nachher; Vergleich mit dem Zielbild |
| Regression | Unit 714 Tests (4 übersprungen) (Python 3.13) und 714 Tests (6 übersprungen) (Python 3.10), Browser 46 von 46 und 46 von 46 in zwei Läufen hintereinander |

**Selbstbewertung 4 von 5.** Abzug: die Formulare in den Abschnitten, Ausgaben, Auswertung und Steuer & Export stehen noch in ihren alten Bausteinen (nur eingebettet); „Kalender & Postfach“ ist mit 2.847 px weiter lang; Editor und geöffnete Rechnung haben keine eigene Adresse; „Spalten ▾“ und „zuletzt exportiert“ aus dem Zielbild fehlen; der Rechnungszweck steht nicht in der Liste (Server unverändert); nur in Chromium geprüft.

## Arbeitspaket 53 – Firmenakte auf dem Baukasten, Begriff „Firma“ (2.0.0-dev54)

Schritt 6 und Abschluss der Etappe E. Grundsatz „keine Funktion entfällt“: jede verschobene Funktion mit altem Ort, neuem Ort und Prüffall in [UI_BAUKASTEN.md](UI_BAUKASTEN.md) („Was wohin zog (Schritt 6)“). Datenmodell, Kontaktsperre, Personen-Einschränkungen, Löschfristen, Fokusführung und Eingabeschutz unverändert; `akte.js` zeichnet den Überblick neu (Vereinbart, Chancen, Klappzeilen, Kontextspalte), `index.html` hat einen neuen Kopf und Karten statt Abschnitten. Am Server nur Meldungstexte („Lead …“ → „Firma …“, rund 100 Stellen in 20 Modulen).

| Prüfung | Ergebnis |
|---|---|
| Abnahmemaße (1280 × 720, Firma mit Gespräch und Chance) | „Vereinbart“ bei 184 px (vorher Kasten bei 252 px, Ziel ≤ 200); Kontextspalte ab 184 px, 320 px breit; erste Chance 351–407 px (vorher nur im Reiter „Bedarf & Angebot“); Kopf 82 px, Reiter 132 px wie auf allen Detailseiten; Überblick 583 statt 1.454 px; sichtbare grüne Knöpfe 1 statt 3. 390 × 844: „Vereinbart“ bei 281 px (vorher 317), kein waagerechtes Scrollen auf allen fünf Reitern |
| Neuer Browser-Test | `test_ui_akte_browser.py`: Seitenkopf (← Firmen, Name, Phase, Ort · Branche), genau eine Hauptaktion, fünf Reiter mit Fokus auf „Überblick“, Abnahmemaße, „Vereinbart“ getrennt von „Empfehlung“, Chancenliste mit Spalten und Wert, Kontextspalte mit Kontaktstatus und Phasen, Zeile → Chance im Reiter, Hauptaktion → Protokoll, gesperrte Firma (Pille im Kopf, rote Meldung ohne Aufklappen, keine Aktion in der Empfehlung, Hauptaktion „Notiz erfassen“), „← Firmen“ mit Suchfilter, „＋ Neue Firma“ per Knopf und Strg+K, kein sichtbares „Lead“ (Text, Platzhalter, Auswahltexte, `title`, `aria-label`, alle Klappzeilen offen) in Akte (alle Reiter), neuer Firma, Firmenliste, Heute, Angebote, Abrechnen, Einstellungen, 390 × 844, keine Seitenfehler, keine Abrufe nach außen |
| Angepasste Erwartungen | `test_akte_tabs_browser` (Phase jetzt als Pille `#modalPhase` statt „Phase …“ in `#modalMeta`, Zusatz Ort · Branche zusätzlich geprüft; „Neue Firma“ statt „Neuer Lead“), `test_akte_page_browser` („← Firmen“ statt „← Zurück“; `aria-label` mit „zurück“ zusätzlich geprüft), `test_assessment_browser` (Bewertung in der Klappzeile „Passung“ – erst aufklappen), Unit `test_phase4_center` (Quelle „Stammdaten“ statt „Lead“) – keine Prüfung abgeschwächt oder übersprungen. `test_ui_workday` blieb unverändert: die Klappzeile „Bedarf“ hat die Kennung `#lfNeed`, „Quellen & Belege“ öffnet sich bei einem Website-Vorschlag selbst |
| Gefunden und behoben | (1) Die Hauptaktion „Gespräch notieren“ wählte die Art vor und machte das Protokoll damit „ungespeichert“ – beim Verlassen der Akte holte der Eingabeschutz die Vorwahl später als „wiederhergestellte Eingabe“ zurück und öffnete den Reiter Kontakt (vom neuen Test gefunden). Die Vorwahl gilt jetzt als Ausgangsstand, solange kein Text getippt ist. (2) Nach „Bedarf bestätigen“ zeichnete der Überblick neu und klappte alles zu – „Angebot aus bestätigtem Bedarf“ war verdeckt; offene Klappzeilen bleiben jetzt offen. (3) Der 3-Sekunden-Abruf während des Impressum-Lesens zeichnete den Überblick neu und hätte Text im Bedarfsformular ersetzt; jetzt mit `uiKeep`. (4) Klappzeile mit Aktion: das › stand auf dem Smartphone in eigener Zeile (Baukasten). (5) Spaltenbreiten der Chancenliste zuerst über `--ui-cols` – der Baukasten-Test verlangt die Variable nur einmal; jetzt eigene Spaltenregel |
| Begriffe | grep `-i "lead"` über `sales_tool/public/*.js`, `index.html` und Zeichenketten in `sales_tool/*.py`; übrig sind interne Namen, Dateinamen, Kommentare/Docstrings und gespeicherte Alttexte (Liste in [EINSCHRAENKUNGEN.md](EINSCHRAENKUNGEN.md)). Im Browser geprüft über den sichtbaren Text von sechs Bereichen |
| Selbst angesehen | Akte (alle Reiter, Firma mit Chance, gesperrte Firma), Neue Firma bei 1280 × 720 in Klassisch hell und Schiefer dunkel, Akte bei 390 × 844, vorher/nachher; Vergleich mit dem Zielbild `z_akte.png`/`m_akte.png` |
| Regression | Unit 714 Tests (4 übersprungen) (Python 3.13) und 714 Tests (6 übersprungen) (Python 3.10), Browser 47 von 47 und 47 von 47 in zwei Läufen hintereinander; ein Zwischenlauf scheiterte nur an der noch nicht neu erzeugten SBOM (Versionsnummer) |

**Selbstbewertung 4 von 5.** Abzug: Die Inhalte der Reiter (Chancenkarten, Bedarfsanalyse, Recherche-Blöcke, Personen, Stammdatenformular) stehen weiter in ihren alten Bausteinen, nur in Karten und Klappzeilen eingebettet; „Vereinbart“ kennt keine echte Herkunft (wann/wo zugesagt), weil SignalDesk das nicht speichert; Anruf/Termin/Mail führen weiter aus der Akte hinaus nach „Kontakt & Termine“; nur in Chromium geprüft.

### Gesamtbilanz Etappe E (Schritte 1–6, dev49 bis dev54)

Alle Werte bei 1280 × 720 bzw. 390 × 844 aus den Einträgen der Arbeitspakete 48–53; Ziel jeweils in Klammern.

| Bereich | Messung | vorher | nachher |
|---|---|---|---|
| Rahmen (Schritt 1/2) | 390 px: andere Bereiche erreichbar | keiner (Seitenleiste ausgeblendet) | alle sechs über „☰ Menü“ |
| | Kopfzeile | 82 px | 52 px |
| Firmen (Schritt 2) | erste Firmenzeile (≤ 280) | 574 px | 221 px |
| | Zeilen ganz sichtbar (≥ 7) | 2 | 8 |
| | 390 px: erste Firmenzeile | 846 px (unter dem Bildrand) | 342 px |
| Heute (Schritt 2) | „Als Nächstes“ (≤ 200) | 342 px | 184 px |
| Finden (Schritt 3) | „Suche starten“ (≤ 140) | 1.455 px | 78 px |
| | Sichten: erste Trefferzeile (≤ 280) / Zeilen sichtbar | 2.124 px / 0 | 221 px / 8 |
| Angebote (Schritt 4) | erste Angebotszeile (≤ 280) / Seitenhöhe | 2.221 px / 3.550 px | 221 px / 720 px |
| | geöffnetes Angebot: erste Position (≤ 260) | 3.939 px („Gespeichertes Angebot“) | 221 px |
| | 390 px: erstes Angebot | 4.144 px | 330 px |
| Einstellungen (Schritt 5) | Inhalt (≤ 200) / Seitenhöhe | 377 px / 13.728 px | 184 px / 1.026–2.847 px je Abschnitt |
| Abrechnen (Schritt 5) | erste Rechnungszeile (≤ 280) | 436 px (nach Wechsel des inneren Reiters) | 221 px |
| | 390 px: erste Rechnungszeile | 646 px | 374 px |
| Firmenakte (Schritt 6) | „Vereinbart“ (≤ 200) / Überblick | 252 px / 1.454 px | 184 px / 583 px |
| | Kontextspalte, erste Chance im ersten Bildschirm | nein / nein | ja (184 px) / ja (bis 407 px) |
| | grüne Knöpfe im Überblick (genau 1) | 3 | 1 |
| Begriffe | sichtbares „Lead“ in den sechs Bereichen | in Kopfzeile, Akte, Dialogen, Meldungen | keines (Browser-Test) |

Über die Etappe: sechs neue Browser-Tests für die Abnahmemaße (`test_mobile_nav_browser`, `test_ui_firmen_heute_browser`, `test_ui_finden_browser`, `test_ui_angebote_browser`, `test_ui_einstellungen_abrechnen_browser`, `test_ui_akte_browser`) und `test_keep_input_browser`; Browser-Tests von 39 auf 47. Bestehende Erwartungen wurden nur an neue Orte und Texte angepasst, nie abgeschwächt. Offen nach der Etappe: die eingebetteten Altteile (Liste in [UI_BAUKASTEN.md](UI_BAUKASTEN.md) und [EINSCHRAENKUNGEN.md](EINSCHRAENKUNGEN.md)), nicht umgebaute Ansichten (Pipeline, Datenpflege, Kontakt & Termine, Kaufsignale, Recherche & Berichte, Analysen, Import), „Spalten ▾“ in Angeboten und Abrechnen; alles nur in Chromium geprüft, nicht auf echten Geräten.

