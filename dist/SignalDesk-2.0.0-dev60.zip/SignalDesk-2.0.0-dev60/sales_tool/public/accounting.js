'use strict';
// v1.0 Rechnungen & Buchhaltung: lokale Rechnungsstellung, Zahlungen, Ausgaben, UStVA-/EÜR-Vorbereitung.
// Nutzt die Helfer aus app.js ($, $$, api, toast, escapeHTML, leads, switchView, showModal, reload, fmtDate).
// 2.0.0-dev53 (UX Schritt 5): Abrechnen hat vier Reiter (Ansichten) statt fünf innerer Reiter – Rechnungen (accounting), Ausgaben (expenses),
// Auswertung (revenue), Steuer & Export (tax). Rechnungen als Liste aus dem Baukasten (Suche, Ansichten, Filter; nächster Schritt nur aus
// vorhandenen Daten); Editor und geöffnete Rechnung als eigene Ansicht mit „← Rechnungen“. Stammdaten und Backup stehen unter
// Einstellungen → Meine Firma bzw. Sicherung & Zugang (dieselben Formulare, window.accLoadSettings). Buchhaltungsregeln unverändert.
(function () {
  const money = c => new Intl.NumberFormat('de-DE', {style: 'currency', currency: 'EUR'}).format((Number(c) || 0) / 100);
  // SDQ-001: Eintrag „Angenommen, noch nicht abgerechnet“ je nach Rechnungsstand
  function unbilledItem(p) {
    const b = p.billing || {state: 'offen'}, pct = p.deposit_pct ?? 40;
    const note = {offen: 'noch nicht abgerechnet', storniert: 'Rechnung storniert – neu abrechnen',
      entwurf: `Rechnungsentwurf vorhanden, noch nicht festgeschrieben${b.remaining_net_cents ? ` · ${money(b.remaining_net_cents)} netto` : ''}`,
      teilweise: `teilweise abgerechnet: ${money(b.invoiced_net_cents)} von ${money(b.target_net_cents)} netto · <b>${money(b.remaining_net_cents)} netto noch abzurechnen</b>${b.draft_count ? ' · Entwurf vorhanden' : ''}`,
      monatlich: 'monatliche Leistung, noch keine Monatsrechnung'}[b.state] || esc(b.state_label || '');
    let buttons;
    if (b.draft_count) buttons = `<button type="button" class="btn btn-primary" data-acc-open="${b.draft_ids[0]}">Entwurf öffnen</button>`;
    else if (b.state === 'teilweise') buttons = `<button type="button" class="btn btn-primary" data-acc-from-proposal="${p.id}" data-mode="schluss">Schlussrechnung über den Rest</button>`;
    else buttons = `${!p.monthly && pct ? `<button type="button" class="btn btn-ghost" data-acc-from-proposal="${p.id}" data-mode="abschlag">Abschlag ${esc(pct)} %</button>` : ''}<button type="button" class="btn btn-primary" data-acc-from-proposal="${p.id}" data-mode="voll">Rechnung</button>`;
    return `<div class="sales-item" data-billing-state="${esc(b.state)}"><div><strong>${esc(p.company)} · ${esc(p.project_label)}</strong><small>Angebot ${esc(p.number)} angenommen · ${note}</small></div><div class="acc-btn-group">${buttons}</div></div>`;
  }
  const esc = v => escapeHTML(String(v ?? ''));
  const deDate = s => s ? new Intl.DateTimeFormat('de-DE').format(new Date(`${s}T12:00:00`)) : '–';
  const iso = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const statusNames = {entwurf: 'Entwurf', offen: 'Offen', teilbezahlt: 'Teilbezahlt', bezahlt: 'Bezahlt', storniert: 'Storniert'};
  const kindNames = {rechnung: 'Rechnung', abschlag: 'Abschlag', schluss: 'Schlussrechnung', storno: 'Storno'};
  const methodNames = {ueberweisung: 'Überweisung', lastschrift: 'Lastschrift', paypal: 'PayPal', bar: 'Bar', sonstiges: 'Sonstiges'};
  let catalog = null, settings = null, editingId = null, invoices = [], invView = 'alle';
  const VIEWS = ['accounting', 'expenses', 'revenue', 'tax'];
  const LOAD = {accounting: () => Promise.all([loadInvoices(), loadOverview()]), expenses: () => loadExpenses(),
    revenue: () => Promise.all([loadOverview(), loadReport()]), tax: () => loadReport()};
  const here = () => (typeof currentView !== 'undefined' && VIEWS.includes(currentView) ? currentView : 'accounting');

  async function loadCatalog() {
    if (catalog) return;
    catalog = await api('/accounting/catalog');
    $('#accCategory').innerHTML = Object.entries(catalog.expense_categories)
      .map(([k, c]) => `<option value="${esc(k)}">${esc(c.label)} (${esc(c.account)})</option>`).join('');
  }

  // Rechnungen: Liste, Editor oder geöffnete Rechnung
  function setMode(mode) {
    $('#viewAccounting').dataset.accMode = mode;
    $('#accList').classList.toggle('hidden', mode !== 'list');
    $('#accEditor').classList.toggle('hidden', mode !== 'edit');
    $('#accDetail').classList.toggle('hidden', mode !== 'detail');
    if (mode === 'list') editingId = null;
    window.scrollTo({top: 0, behavior: 'instant'});
  }

  // SDQ-003: Zurück/Vor auf #/abrechnen zeigt die Liste – ein Entwurf mit ungespeicherten Eingaben bleibt aber offen
  window.accShowList = () => { if ($('#viewAccounting').dataset.accMode !== 'list' && !editorDirty()) { setMode('list'); loadInvoices(); } };

  window.refreshAccounting = async function (view) {
    try { await loadCatalog(); settings = await api('/accounting/settings'); await LOAD[view || here()](); }
    catch (e) { toast(e.message, true); }
  };

  // ------------------------------------------------------------ Übersicht
  async function loadOverview() {
    try {
      const o = await api('/accounting/overview');
      $('#accOpen').textContent = money(o.open_cents);
      $('#accOpenCount').textContent = `${o.open_count} Rechnung(en) · ${o.drafts} Entwürfe`;
      $('#accOverdue').textContent = money(o.overdue_cents);
      $('#accOverdueCount').textContent = `${o.overdue_count} überfällig`;
      $('#accPaidYear').textContent = money(o.paid_year_cents);
      $('#accInvoicedYear').textContent = `Berechnet netto: ${money(o.invoiced_year_net_cents)}`;
      $('#accQuarter').textContent = money(o.quarter.payable_cents);
      $('#accQuarterRange').textContent = `${deDate(o.quarter.from)} – ${deDate(o.quarter.to)} · Vorbereitung`;
      $('#accWarnings').innerHTML = o.warnings.map(w => `<div class="sales-banner sales-warning acc-warning">${esc(w)}</div>`).join('');
      // 2.0.0-dev53: Stammdaten-Warnung als Klappzeile unter der Rechnungsliste, mit Sprung nach Einstellungen → Meine Firma
      const miss = settings?.missing || [];
      $('#accMasterFold').classList.toggle('hidden', !o.warnings.length);
      $('#accMasterState').innerHTML = miss.length ? `<span class="ui-pill is-attention">${esc(miss.length === 1 ? miss[0] + ' fehlt' : miss.length + ' Pflichtangaben fehlen')}</span> ohne sie keine Festschreibung`
        : o.warnings.length ? `<span class="ui-pill is-attention">prüfen</span> ${esc(o.warnings[0])}` : '';
      $('#accMasterLink').classList.toggle('hidden', !miss.length);
      // SDQ-001: angenommen, aber noch nicht vollständig abgerechnet – mit Restbetrag (Abschlag ≠ abgerechnet, Entwurf ≠ abgerechnet)
      const unbilled = o.accepted_without_invoice, rest = unbilled.reduce((sum, p) => sum + (p.billing?.remaining_net_cents || 0), 0);
      $('#accUnbilledState').textContent = unbilled.length ? `${unbilled.length} angenommene${unbilled.length === 1 ? 's Angebot' : ' Angebote'} noch nicht vollständig abgerechnet${rest ? ` · ${money(rest)} netto offen` : ''}` : 'alle angenommenen Angebote sind vollständig abgerechnet';
      $('#accTaxState').textContent = `USt-Zahllast laufendes Quartal ${money(o.quarter.payable_cents)} (Vorbereitung) · EÜR, CSV-Exporte, Änderungsprotokoll`;
      $('#accOverdueList').innerHTML = o.overdue.length ? o.overdue.map(r => `<div class="sales-item"><div><strong>${esc(r.number)} · ${esc(r.buyer_name)}</strong><small>${money(r.outstanding_cents)} offen · ${r.overdue_days} Tage überfällig${r.dunning_level ? ' · Mahnstufe ' + r.dunning_level : ''}</small></div><button type="button" class="btn btn-ghost" data-acc-open="${r.id}">Öffnen</button></div>`).join('') : '<div class="empty">Keine überfälligen Rechnungen.</div>';
      $('#accUnbilled').innerHTML = unbilled.length ? unbilled.map(unbilledItem).join('') : '<div class="empty">Alle angenommenen Angebote sind vollständig abgerechnet.</div>';
      const max = Math.max(1, ...o.months.flatMap(m => [m.invoiced_net_cents, m.paid_cents]));
      $('#accMonths').innerHTML = o.months.map(m => `<div class="acc-bar-col" title="${esc(m.month)}: berechnet ${money(m.invoiced_net_cents)}, bezahlt ${money(m.paid_cents)}"><div class="acc-bar-pair"><i class="inv" data-h="${Math.round(100 * m.invoiced_net_cents / max)}"></i><i class="paid" data-h="${Math.round(100 * m.paid_cents / max)}"></i></div><small>${esc(m.month.slice(5))}/${esc(m.month.slice(2, 4))}</small></div>`).join('');
      // CSP: keine style-Attribute im HTML – Höhen per CSSOM setzen.
      $$('#accMonths [data-h]').forEach(el => { el.style.height = el.dataset.h + '%'; });
    } catch (e) { toast(e.message, true); }
  }

  async function fromProposal(id, mode) {
    try {
      // 2.0.0-dev16: Abschlag laut Angebot (Kalkulationsgrundlagen), ältere Angebote 40 % – der Server liest den Wert aus dem Angebot
      const inv = await api('/accounting/invoices/from-proposal', 'POST', {proposal_id: id, mode});
      toast('Rechnungsentwurf aus Angebot erstellt – Empfängeradresse prüfen');
      if (here() !== 'accounting') switchView('accounting');
      loadInvoices();
      openEditor(inv);
    } catch (e) { toast(e.message, true); }
  }
  window.accInvoiceFromProposal = async function (id, mode) { switchView('accounting'); await window.refreshAccounting(); await fromProposal(id, mode); };

  // ------------------------------------------------------------ Rechnungen
  async function loadInvoices() {
    try { invoices = await api('/accounting/invoices'); renderInvoices(); }
    catch (e) { toast(e.message, true); }
  }

  const isOpen = r => ['offen', 'teilbezahlt'].includes(r.status);
  const IN_VIEW = {alle: () => true, offen: isOpen, ueberfaellig: r => isOpen(r) && r.overdue_days > 0, bezahlt: r => r.status === 'bezahlt', entwurf: r => r.status === 'entwurf'};
  const short = s => s ? new Date(`${s}T12:00:00`).toLocaleDateString('de-DE', {day: 'numeric', month: 'short'}) : '–';
  // Nächster Schritt nur aus vorhandenen Daten: Entwurf → festschreiben (oder erst Stammdaten), offen → abwarten bzw. erinnern
  function nextStep(r) {
    if (r.status === 'entwurf') return settings?.missing?.length ? 'Stammdaten ergänzen' : 'Prüfen und festschreiben';
    if (!isOpen(r)) return '–';
    if (r.overdue_days > 0) return r.dunning_level ? `Zahlung erinnern (Mahnstufe ${r.dunning_level} erstellt)` : 'Zahlung erinnern';
    return r.status === 'teilbezahlt' ? 'Restzahlung abwarten' : 'Zahlungseingang abwarten';
  }
  function dueCell(r) {
    if (!isOpen(r) || !r.due_date) return '<span class="ui-small">–</span>';
    if (r.overdue_days > 0) return `<span class="ui-pill is-overdue">${r.overdue_days === 1 ? '1 Tag' : r.overdue_days + ' Tage'} überfällig</span>`;
    if (r.due_date === iso(new Date())) return '<span class="ui-pill is-attention">heute</span>';
    return `<span class="acc-date">${short(r.due_date)}</span>`;
  }
  function statusPill(r) {
    if (r.kind === 'storno') return '<span class="ui-pill">Storno</span>';
    const cls = {bezahlt: 'is-done', offen: 'is-underway', teilbezahlt: 'is-underway', entwurf: '', storniert: ''}[r.status] || '';
    return `<span class="ui-pill ${cls}">${esc(statusNames[r.status] || r.status)}</span>`;
  }
  function renderInvoices() {
    const q = $('#accQ').value.trim().toLowerCase(), st = $('#accInvoiceFilter').value;
    const match = r => (!q || [r.number, r.buyer_name, kindNames[r.kind], 'Entwurf #' + r.id].join(' ').toLowerCase().includes(q)) && (!st || r.status === st);
    $$('[data-acc-cnt]').forEach(c => { const n = invoices.filter(r => IN_VIEW[c.dataset.accCnt](r)).length; c.textContent = n ? String(n) : ''; });
    $$('[data-acc-view]').forEach(b => { const on = b.dataset.accView === invView; b.classList.toggle('is-active', on); b.setAttribute('aria-pressed', String(on)); });
    $('#accFilterBtn').classList.toggle('is-active', !!st);
    const rows = invoices.filter(r => IN_VIEW[invView](r) && match(r));
    const focused = document.activeElement?.closest?.('#accInvoiceRows [data-acc-open]')?.dataset.accOpen;  // Fokus übersteht das Neuzeichnen
    $('#accCount').textContent = rows.length === invoices.length ? `${invoices.length} ${invoices.length === 1 ? 'Rechnung' : 'Rechnungen'}` : `${rows.length} von ${invoices.length} Rechnungen`;
    $('#accInvoiceRows').innerHTML = rows.length ? rows.map(r => `<div class="ui-row acc-row" role="listitem" tabindex="0" data-acc-open="${r.id}" aria-label="${esc(r.number || 'Entwurf #' + r.id)} öffnen">
        <div class="ui-main"><b>${esc(r.number || 'Entwurf #' + r.id)}</b><small>${esc(r.buyer_name || '–')} · ${esc(kindNames[r.kind] || r.kind)}${r.issue_date ? ' vom ' + esc(deDate(r.issue_date)) : ''}</small></div>
        <div class="ui-cut" title="${esc(nextStep(r))}">${esc(nextStep(r))}</div>
        <div>${dueCell(r)}</div>
        <div>${statusPill(r)}</div>
        <div class="ui-num">${money(r.gross_cents)}${r.status === 'teilbezahlt' ? `<small>offen ${money(r.outstanding_cents)}</small>` : ''}</div>
        <div class="ui-chev" aria-hidden="true">›</div></div>`).join('')
      : `<div class="ui-empty">${invoices.length ? 'Keine Rechnung passt zu Suche, Ansicht und Filter.' : 'Noch keine Rechnungen. Ergänze die Stammdaten und erstelle die erste Rechnung – oder übernimm ein angenommenes Angebot.'}</div>`;
    if (focused) $(`#accInvoiceRows [data-acc-open="${focused}"]`)?.focus({preventScroll: true});
  }

  function leadOptions(selected) {
    return '<option value="">– ohne Firma –</option>' + leads.map(l => `<option value="${l.id}" ${String(l.id) === String(selected ?? '') ? 'selected' : ''}>${esc(l.company)}</option>`).join('');
  }

  function lineRow(line = {}) {
    const units = Object.entries(catalog.units).map(([k, v]) => `<option value="${esc(k)}" ${k === (line.unit || 'pauschal') ? 'selected' : ''}>${esc(v)}</option>`).join('');
    const rates = catalog.vat_rates.map(r => `<option value="${r}" ${r === (line.vat_rate ?? 19) ? 'selected' : ''}>${r} %</option>`).join('');
    const price = line.unit_price_cents !== undefined ? (line.unit_price_cents / 100).toFixed(2).replace('.', ',') : '';
    const qty = String(line.quantity ?? '1').replace('.', ',');
    return `<tr class="acc-line"><td><textarea data-f="description" rows="2" maxlength="1000" required aria-label="Beschreibung">${esc(line.description || '')}</textarea></td><td><input data-f="quantity" value="${esc(qty)}" inputmode="decimal" aria-label="Menge"></td><td><select data-f="unit" aria-label="Einheit">${units}</select></td><td><input data-f="unit_price_eur" value="${esc(price)}" inputmode="decimal" placeholder="0,00" aria-label="Einzelpreis"></td><td><select data-f="vat_rate" aria-label="Steuersatz">${rates}</select></td><td class="num" data-net>–</td><td><button type="button" class="del-task" data-acc-del-line aria-label="Position entfernen">✕</button></td></tr>`;
  }

  const parseNum = v => { const s = String(v ?? '').trim().replace(/\s|€/g, ''); return Number(s.includes(',') ? s.replace(/\./g, '').replace(',', '.') : s); };

  function collectLines() {
    return $$('#accLines .acc-line').map(tr => {
      const get = f => tr.querySelector(`[data-f="${f}"]`).value;
      return {description: get('description'), quantity: get('quantity').replace(',', '.'), unit: get('unit'), unit_price_eur: get('unit_price_eur'), vat_rate: Number(get('vat_rate'))};
    });
  }

  function updateTotals() {
    const mode = $('#accTaxMode').value;
    const groups = {};
    $$('#accLines .acc-line').forEach(tr => {
      const q = parseNum(tr.querySelector('[data-f="quantity"]').value), p = parseNum(tr.querySelector('[data-f="unit_price_eur"]').value);
      const rate = mode === 'regel' ? Number(tr.querySelector('[data-f="vat_rate"]').value) : 0;
      tr.querySelector('[data-f="vat_rate"]').disabled = mode !== 'regel';
      const net = Number.isFinite(q * p) ? Math.round(q * p * 100) : 0;
      tr.querySelector('[data-net]').textContent = money(net);
      groups[rate] = (groups[rate] || 0) + net;
    });
    let net = 0, vat = 0, rows = '';
    Object.keys(groups).map(Number).sort((a, b) => b - a).forEach(rate => {
      const v = Math.round(groups[rate] * rate / 100); net += groups[rate]; vat += v;
      if (mode === 'regel') rows += `<small>zzgl. ${rate} % USt. auf ${money(groups[rate])}: ${money(v)}</small>`;
    });
    const note = mode === 'kleinunternehmer' ? '<small>Gemäß § 19 UStG wird keine Umsatzsteuer berechnet.</small>' : mode === 'reverse_charge' ? '<small>Steuerschuldnerschaft des Leistungsempfängers (Reverse Charge).</small>' : '';
    $('#accTotals').innerHTML = `<small>Summe netto ${money(net)}</small>${rows}${note}<strong>${money(net + vat)}</strong><small>Rechnungsbetrag (Vorschau, Server rechnet verbindlich)</small>`;
  }

  function openEditor(inv) {
    setMode('edit');
    editingId = inv?.id || null;
    const f = $('#accInvoiceForm');
    f.reset();
    $('#accLeadSelect').innerHTML = leadOptions(inv?.lead_id);
    const defaults = {buyer_country: 'DE', payment_days: settings?.payment_days ?? 14, tax_mode: settings?.small_business ? 'kleinunternehmer' : 'regel', kind: 'rechnung'};
    const data = {...defaults, ...(inv || {})};
    for (const key of ['kind', 'buyer_name', 'buyer_contact', 'buyer_street', 'buyer_zip', 'buyer_city', 'buyer_country', 'buyer_vat_id', 'buyer_reference', 'buyer_email', 'issue_date', 'service_from', 'service_to', 'tax_mode', 'payment_days', 'intro_text', 'closing_text']) {
      if (f.elements[key] && data[key] !== undefined && data[key] !== null) f.elements[key].value = data[key];
    }
    $('#accLines').innerHTML = (inv?.lines?.length ? inv.lines : [{}]).map(lineRow).join('');
    $('#accEditorTitle').textContent = inv?.id ? `Entwurf #${inv.id} bearbeiten` : 'Neue Rechnung';
    $('#accEditorKicker').textContent = inv?.kind ? `${kindNames[inv.kind] || 'Rechnung'} · Entwurf` : 'Entwurf – noch nicht gespeichert';
    ['#accDeleteDraft', '#accPreview', '#accFinalize'].forEach(s => $(s).classList.toggle('hidden', !editingId));
    $('#accChecks').innerHTML = inv?.checks?.length ? `<div class="sales-banner sales-warning"><b>Vor der Festschreibung fehlt:</b><ul>${inv.checks.map(c => `<li>${esc(c)}</li>`).join('')}</ul></div>` : (editingId ? '<div class="sales-banner">Pflichtangaben vollständig. Nach der Festschreibung ist die Rechnung unveränderbar.</div>' : '');
    updateTotals();
    editorBase = editorSnap();
  }

  // ---- SDQ-003 (Audit B2): Eingabeschutz für den Rechnungsentwurf
  // Ungespeicherte Eingaben im Editor gehen weder beim Wechsel des Bereichs, beim Schließen des Editors, beim Öffnen einer anderen
  // Rechnung noch beim Neuladen/Schließen des Fensters still verloren. Rückfrage wie in Akte und Einstellungen (formguard.js):
  // Speichern (als Entwurf – nie festschreiben) · Weiter bearbeiten (nichts passiert) · Verwerfen.
  let editorBase = null;
  const editorSnap = () => JSON.stringify([...$('#accInvoiceForm').querySelectorAll('input, select, textarea')]
    .filter(el => !['submit', 'button', 'reset', 'file'].includes(el.type)).map(el => (el.type === 'checkbox' || el.type === 'radio' ? el.checked : el.value)));
  const editorDirty = () => $('#viewAccounting')?.dataset.accMode === 'edit' && editorBase !== null && editorSnap() !== editorBase;
  window.accEditorDirty = editorDirty;
  const LEAVE = '.sidebar .nav, .nav-help, [data-go], [data-area-view], [data-view-link], [data-settings-jump], [data-settings-link], '
    + '[data-go-action], #accEditorClose, #accNewInvoice, [data-acc-open], [data-acc-from-proposal], [data-acc-close-detail]';
  let replaying = false;
  async function guardLeave(e) {
    if (replaying || !editorDirty() || !window.formGuard) return;
    const target = e.target.closest && e.target.closest(LEAVE);
    if (!target || (target.closest('#accEditor') && !target.matches('#accEditorClose'))) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    const choice = await window.formGuard.ask(['Rechnungsentwurf']);
    if (choice === 'edit') { $('#accInvoiceForm [name=buyer_name]')?.focus(); return; }
    if (choice === 'save' && !(await saveDraft())) return;  // Fehler: Eingaben bleiben stehen, Meldung kam vom Speichern
    if (choice === 'discard') { if (editingId) await openInvoice(editingId); else setMode('list'); }  // gespeicherten Stand wiederherstellen
    replaying = true;
    try { target.click(); } finally { replaying = false; }
  }
  window.addEventListener('click', guardLeave, true);  // vor den Klick-Verteilern von nav.js und app.js
  window.addEventListener('beforeunload', e => { if (editorDirty()) { e.preventDefault(); e.returnValue = ''; } });

  function invoicePayload() {
    const f = $('#accInvoiceForm'), d = Object.fromEntries(new FormData(f).entries());
    d.lead_id = d.lead_id ? Number(d.lead_id) : null;
    d.payment_days = Number(d.payment_days || 0);
    d.lines = collectLines();
    return d;
  }

  async function saveDraft(e) {
    e?.preventDefault();
    try {
      const inv = await api('/accounting/invoices' + (editingId ? '/' + editingId : ''), editingId ? 'PUT' : 'POST', invoicePayload());
      toast('Entwurf gespeichert');
      openEditor(inv);
      loadInvoices();
      return inv;
    } catch (err) { toast(err.message, true); return null; }
  }

  async function finalize() {
    const inv = await saveDraft();
    if (!inv) return;
    if (inv.checks.length) { toast('Pflichtangaben fehlen – siehe Hinweis', true); return; }
    if (!confirm('Rechnung festschreiben? Danach erhält sie eine fortlaufende Nummer und ist unveränderbar. Korrekturen nur per Storno.')) return;
    try {
      const final = await api(`/accounting/invoices/${inv.id}/finalize`, 'POST', {confirm: true});
      toast(`Rechnung ${final.number} festgeschrieben – nichts wurde versendet`);
      loadInvoices();
      showDetail(final);
    } catch (err) { toast(err.message, true); }
  }

  async function openInvoice(id) {
    try {
      const inv = await api('/accounting/invoices/' + id);
      if (inv.status === 'entwurf') openEditor(inv); else showDetail(inv);
    } catch (e) { toast(e.message, true); }
  }

  window.accOpenInvoice = openInvoice;

  function showDetail(inv) {
    setMode('detail');
    const el = $('#accDetail');
    const open = ['offen', 'teilbezahlt'].includes(inv.status);
    const payments = inv.payments.length ? inv.payments.map(p => `<div class="sales-item"><div><strong>${money(p.amount_cents)} · ${deDate(p.paid_on)}</strong><small>${esc(methodNames[p.method] || p.method)}${p.note ? ' · ' + esc(p.note) : ''}</small></div><button type="button" class="btn btn-ghost" data-acc-del-payment="${p.id}">Zurücknehmen</button></div>`).join('') : '<div class="empty">Noch kein Zahlungseingang.</div>';
    const dunning = inv.dunning.map(d => `<details class="acc-dunning"><summary>${esc(catalog.dunning_levels[d.level])} vom ${deDate(d.created_on)} · neue Frist ${deDate(d.new_due_date)}</summary><pre>${esc(d.text)}</pre></details>`).join('');
    // 2.0.0-dev53: geöffnete Rechnung als eigene Ansicht – „← Rechnungen“, Nummer, Status, Hauptaktion Drucken / PDF
    el.innerHTML = `<div class="ui-head"><button type="button" class="ui-back" data-acc-close-detail>← Rechnungen</button><h1>${esc(inv.number)}</h1>${statusPill(inv)}<span class="ui-meta">${esc(inv.buyer_name)} · ${esc(kindNames[inv.kind] || '')}</span><span class="ui-sp"></span><a class="btn btn-primary" href="/rechnung/${inv.id}" target="_blank" rel="noopener">Drucken / PDF ↗</a></div>
      <div class="ui-card acc-detail"><div class="acc-detail-grid"><div><small>Rechnungsdatum</small><b>${deDate(inv.issue_date)}</b></div><div><small>Fällig</small><b>${deDate(inv.due_date)}</b></div><div><small>Brutto</small><b>${money(inv.gross_cents)}</b></div><div><small>Offen</small><b>${money(inv.outstanding_cents)}</b>${inv.overdue_days ? `<small class="late">${inv.overdue_days} Tage überfällig</small>` : ''}</div></div>
      ${inv.corrects ? `<p class="muted">Storniert Rechnung ${esc(inv.corrects.number)} vom ${deDate(inv.corrects.issue_date)}.</p>` : ''}${inv.corrected_by.length ? `<p class="muted">Storniert durch ${inv.corrected_by.map(c => `<button type="button" class="text-button" data-acc-open="${c.id}">${esc(c.number)}</button>`).join(', ')}.</p>` : ''}
      <div class="acc-btn-group"><a class="btn btn-ghost" href="/api/accounting/invoices/${inv.id}/xrechnung" download>E-Rechnung (XRechnung XML) ↓</a>${inv.kind !== 'storno' ? `<button type="button" class="btn btn-ghost" data-acc-duplicate="${inv.id}">Als neuen Entwurf kopieren</button>` : ''}${inv.status === 'offen' && inv.kind !== 'storno' ? `<button type="button" class="btn btn-danger" data-acc-cancel="${inv.id}">Stornieren</button>` : ''}</div>
      <p class="muted">Die XRechnung ist die rechtlich maßgebliche E-Rechnung für Geschäftskunden; das PDF ist eine Ansichtskopie. Nichts wird automatisch versendet.</p>
      <div class="sales-cols acc-detail-cols">
        <div><div class="sales-subhead">Zahlungseingänge</div><div class="sales-list">${payments}</div>
          ${open ? `<form class="sales-form" id="accPaymentForm"><div class="acc-row3"><label>Betrag €<input name="amount_eur" inputmode="decimal" value="${(inv.outstanding_cents / 100).toFixed(2).replace('.', ',')}"></label><label>Datum<input type="date" name="paid_on" value="${iso(new Date())}"></label><label>Art<select name="method">${catalog.payment_methods.map(m => `<option value="${m}">${esc(methodNames[m])}</option>`).join('')}</select></label></div><label>Notiz (z. B. Kontoauszug-Nr.)<input name="note" maxlength="300"></label><button type="submit" class="btn btn-ghost">Zahlung erfassen</button></form>` : ''}</div>
        <div><div class="sales-subhead">Mahnwesen</div>${dunning || '<div class="empty">Keine Mahnungen.</div>'}
          ${open && inv.overdue_days ? `<form class="sales-form" id="accDunningForm"><label>Stufe<select name="level">${Object.entries(catalog.dunning_levels).map(([k, v]) => `<option value="${k}" ${Number(k) === Math.min(3, (inv.dunning.at(-1)?.level || 0) + 1) ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select></label><label class="quote-addon"><input type="checkbox" name="include_interest"><span>Verzugszinsen (§ 288 Abs. 2 BGB)<small>Basiszins + 9 Prozentpunkte, nur bei Verzug eines Geschäftskunden</small></span></label><label class="quote-addon"><input type="checkbox" name="include_fee"><span>Verzugspauschale 40 € (§ 288 Abs. 5 BGB)</span></label><button type="submit" class="btn btn-ghost">Mahnschreiben entwerfen</button></form><div id="accDunningPreview"></div>` : (open ? '<p class="muted">Noch nicht fällig.</p>' : '')}</div>
      </div></div>`;
    el.dataset.invoiceId = inv.id;
  }

  async function submitPayment(form) {
    const id = Number($('#accDetail').dataset.invoiceId), d = Object.fromEntries(new FormData(form).entries());
    try { const inv = await api(`/accounting/invoices/${id}/payments`, 'POST', d); toast('Zahlung erfasst'); showDetail(inv); loadInvoices(); }
    catch (e) { toast(e.message, true); }
  }

  async function submitDunning(form) {
    const id = Number($('#accDetail').dataset.invoiceId);
    const d = {level: Number(form.elements.level.value), include_interest: form.elements.include_interest.checked, include_fee: form.elements.include_fee.checked};
    try {
      const n = await api(`/accounting/invoices/${id}/dunning`, 'POST', d);
      const inv = await api('/accounting/invoices/' + id);
      showDetail(inv);
      $('#accDunningPreview').innerHTML = `<div class="sales-mail-preview"><b>${esc(n.title)} · Gesamt ${money(n.total_cents)}</b><pre>${esc(n.text)}</pre><button type="button" class="btn btn-ghost" data-acc-copy>Text kopieren</button><p class="muted">${esc(n.notice)}</p></div>`;
      $('#accDunningPreview [data-acc-copy]').onclick = () => navigator.clipboard.writeText(n.text).then(() => toast('Mahntext kopiert'));
      toast('Mahnschreiben erstellt – nicht versendet. Wiedervorlage angelegt.');
    } catch (e) { toast(e.message, true); }
  }

  // ------------------------------------------------------------ Ausgaben
  async function loadExpenses() {
    try {
      const [rows, docs] = await Promise.all([api('/accounting/expenses' + ($('#accShowCancelled').checked ? '?all=1' : '')), api('/accounting/documents')]);
      const f = $('#accExpenseForm');
      if (!f.elements.expense_date.value) f.elements.expense_date.value = iso(new Date());
      $('#accExpCount').textContent = `${rows.filter(x => x.status !== 'storniert').length} erfasst${docs.length ? ` · ${docs.length} E-Rechnung${docs.length === 1 ? '' : 'en'} archiviert` : ''}`;
      $('#accExpenseList').innerHTML = rows.length ? rows.map(x => `<div class="sales-item ${x.status === 'storniert' ? 'acc-cancelled' : ''}"><div><strong>${esc(x.supplier)} · ${money(x.gross_cents)}${x.reverse_charge ? ' · §13b' : ''}</strong><small>${deDate(x.expense_date)} · ${esc(x.category_label)} (${esc(x.account_skr03)}) · ${x.vat_cents ? 'USt. ' + money(x.vat_cents) : 'ohne USt.'} · ${x.paid_on ? 'bezahlt ' + deDate(x.paid_on) : 'unbezahlt'}${x.receipt_ref ? ' · ' + esc(x.receipt_ref) : ''}${x.status === 'storniert' ? ' · STORNIERT' : ''}</small>${x.warnings.map(w => `<small class="late">${esc(w)}</small>`).join('')}</div><div class="acc-btn-group">${x.status === 'aktiv' && !x.paid_on ? `<button type="button" class="btn btn-ghost" data-acc-exp-paid="${x.id}">Heute bezahlt</button>` : ''}${x.document_id ? `<a class="btn btn-ghost" href="/api/accounting/documents/${x.document_id}/xml" download>XML</a>` : ''}${x.status === 'aktiv' ? `<button type="button" class="btn btn-ghost" data-acc-exp-cancel="${x.id}">Storno</button>` : ''}</div></div>`).join('') : '<div class="empty">Noch keine Ausgaben erfasst.</div>';
      $('#accDocuments').innerHTML = docs.length ? docs.slice(0, 15).map(d => `<div class="sales-item"><div><strong>${esc(d.supplier || '?')} · ${esc(d.number || '?')}</strong><small>${esc(d.format)} · ${esc(d.created_at)} · ${d.expense_id ? 'gebucht' : 'noch nicht gebucht'}</small></div><a class="btn btn-ghost" href="/api/accounting/documents/${d.id}/xml" download>Original ↓</a></div>`).join('') : '<div class="empty">Noch keine E-Rechnung importiert.</div>';
    } catch (e) { toast(e.message, true); }
  }

  async function saveExpense(e) {
    e.preventDefault();
    const f = e.target, d = Object.fromEntries(new FormData(f).entries());
    d.reverse_charge = f.elements.reverse_charge.checked;
    d.vat_rate = Number(d.vat_rate);
    if (d.reverse_charge) { d.net_eur = d.gross_eur; delete d.gross_eur; }
    if (!d.document_id) delete d.document_id; else d.document_id = Number(d.document_id);
    for (const k of ['vat_eur', 'paid_on']) if (!d[k]) delete d[k];
    try {
      const x = await api('/accounting/expenses', 'POST', d);
      toast('Ausgabe gespeichert' + (x.warnings.length ? ' – bitte Hinweise beachten' : ''));
      f.reset(); f.elements.document_id.value = ''; f.elements.expense_date.value = iso(new Date()); $('#accEinvoiceResult').innerHTML = '';
      loadExpenses();
    } catch (err) { toast(err.message, true); }
  }

  async function importEinvoice(e) {
    const file = e.target.files[0];
    e.target.value = '';
    if (!file) return;
    if (file.size > 3000000) { toast('Datei zu groß (max. 3 MB)', true); return; }
    try {
      const r = await api('/accounting/einvoice/import', 'POST', {filename: file.name, xml: await file.text()});
      const p = r.parsed, s = r.expense_suggestion, f = $('#accExpenseForm');
      $('#accEinvoiceResult').innerHTML = `<div class="sales-banner"><b>${esc(p.format)}</b> · ${esc(p.supplier)} · Nr. ${esc(p.number)} · ${deDate(p.issue_date)}<br>Netto ${esc(p.net)} · USt. ${esc(p.vat)} · Brutto ${esc(p.gross)} ${esc(p.currency)}${p.due_date ? ' · fällig ' + deDate(p.due_date) : ''}${p.iban ? '<br>IBAN ' + esc(p.iban) : ''}</div>${p.warnings.map(w => `<div class="sales-banner sales-warning">${esc(w)}</div>`).join('')}${r.duplicate ? '<div class="sales-banner sales-warning">Diese Datei wurde bereits importiert.</div>' : ''}${r.already_booked_expense_id ? '<div class="sales-banner sales-warning">Bereits als Ausgabe gebucht.</div>' : ''}<p class="muted">${esc(r.notice)}</p>`;
      if (!r.already_booked_expense_id) {
        f.elements.document_id.value = r.document_id;
        for (const k of ['supplier', 'expense_date', 'receipt_ref', 'description']) f.elements[k].value = s[k] || '';
        f.elements.gross_eur.value = s.reverse_charge ? s.net_eur : s.gross_eur;
        f.elements.vat_eur.value = s.reverse_charge ? '' : s.vat_eur;
        f.elements.vat_rate.value = String(s.vat_rate);
        f.elements.reverse_charge.checked = s.reverse_charge;
        toast('E-Rechnung gelesen – Formular vorausgefüllt, bitte prüfen und speichern');
      }
      loadExpenses();
    } catch (err) { toast(err.message, true); }
  }

  // ------------------------------------------------------------ Auswertung
  function presetRange(kind) {
    const t = new Date(), y = t.getFullYear(), m = t.getMonth(), q = Math.floor(m / 3);
    const r = {
      month: [new Date(y, m, 1), new Date(y, m + 1, 0)], prev_month: [new Date(y, m - 1, 1), new Date(y, m, 0)],
      quarter: [new Date(y, q * 3, 1), new Date(y, q * 3 + 3, 0)], prev_quarter: [new Date(y, q * 3 - 3, 1), new Date(y, q * 3, 0)],
      year: [new Date(y, 0, 1), new Date(y, 11, 31)], prev_year: [new Date(y - 1, 0, 1), new Date(y - 1, 11, 31)],
    }[kind];
    return r ? r.map(iso) : null;
  }

  function applyPreset() {
    const r = presetRange($('#accPreset').value), f = $('#accReportForm');
    if (r) { f.elements.from.value = r[0]; f.elements.to.value = r[1]; }
  }

  async function loadReport(e) {
    e?.preventDefault();
    const f = $('#accReportForm');
    if (!f.elements.from.value) applyPreset();
    const qs = new URLSearchParams({from: f.elements.from.value, to: f.elements.to.value, ...(f.elements.basis.value ? {basis: f.elements.basis.value} : {})}).toString();
    try {
      const [r, k, audit] = await Promise.all([api('/accounting/report?' + qs), api('/accounting/sales-kpis?' + qs), api('/accounting/audit')]);
      $('#accUstva').innerHTML = `<p class="muted">${deDate(r.period.from)} – ${deDate(r.period.to)} · ${r.period.basis === 'ist' ? 'Ist-Versteuerung' : 'Soll-Versteuerung'}</p><table class="acc-table"><thead><tr><th>Kz</th><th>Bezeichnung</th><th class="num">Bemessung</th><th class="num">Steuer</th></tr></thead><tbody>${r.ustva.map(x => `<tr><td><b>${esc(x.kz)}</b></td><td>${esc(x.label)}</td><td class="num">${x.value_eur === null ? '' : x.value_eur.toLocaleString('de-DE') + ' €'}</td><td class="num">${x.tax_cents ? money(x.tax_cents) : ''}</td></tr>`).join('')}</tbody></table><div class="quote-total"><small>Umsatzsteuer ${money(r.output_tax_cents)} − Vorsteuer ${money(r.input_tax_cents)}</small><strong>${money(r.payable_cents)}</strong><small>${r.payable_cents >= 0 ? 'voraussichtliche Zahllast' : 'voraussichtliches Guthaben'}</small></div>${r.hints.map(h => `<div class="sales-banner">${esc(h)}</div>`).join('')}`;
      const eu = r.euer;
      $('#accEuer').innerHTML = `<div class="sales-internal-grid"><span>Betriebseinnahmen (netto, zugeflossen)</span><b>${money(eu.income_net_cents)}</b><span>Vereinnahmte USt.</span><b>${money(eu.income_vat_cents)}</b><span>Betriebsausgaben${r.small_business ? ' (brutto)' : ' (netto)'}</span><b>${money(eu.expenses_cents)}</b><span>Gezahlte Vorsteuer</span><b>${money(eu.input_vat_cents)}</b><span><b>Überschuss (vereinfacht)</b></span><b>${money(eu.profit_cents)}</b></div><div class="sales-subhead">Ausgaben nach Kategorie</div>${eu.by_category.length ? `<div class="sales-internal-grid">${eu.by_category.map(c => `<span>${esc(c.label)}</span><b>${money(c.cents)}</b>`).join('')}</div>` : '<div class="empty">Keine Ausgaben im Zeitraum.</div>'}<p class="muted">${esc(eu.note)}</p>`;
      const route = Object.entries(k.paid_by_contact_route_cents);
      $('#accSalesKpis').innerHTML = `<div class="sales-internal-grid"><span>Angebote erstellt</span><b>${k.proposals_total}</b>${Object.entries(k.proposals_by_status).map(([s, n]) => `<span>· ${esc(s.replaceAll('_', ' '))}</span><b>${n}</b>`).join('')}<span>Annahmequote (angenommen / entschieden)</span><b>${k.acceptance_rate_pct === null ? '–' : k.acceptance_rate_pct + ' %'}</b><span>Ø angenommener Auftragswert netto</span><b>${k.avg_accepted_net_eur === null ? '–' : money(k.avg_accepted_net_eur * 100)}</b><span>Firmen gewonnen / verloren</span><b>${k.leads_won} / ${k.leads_lost}</b></div><div class="sales-subhead">Zahlungseingang nach Kontaktweg</div>${route.length ? `<div class="sales-internal-grid">${route.map(([r, c]) => `<span>${esc(r === 'unbekannt' ? 'Kontaktweg nicht erfasst' : ((typeof routeNames !== 'undefined' && routeNames[r]) || r))}</span><b>${money(c)}</b>`).join('')}</div>` : '<div class="empty">Noch keine Zahlungen mit Firmen-Zuordnung.</div>'}<p class="muted">${esc(k.note)}</p>`;
      $('#accExports').innerHTML = [['rechnungen', 'Rechnungsausgangsbuch'], ['ausgaben', 'Ausgaben / Belege'], ['buchungen', 'Buchungsliste (SKR03-Vorschlag)']].map(([kind, label]) => `<a class="btn btn-ghost" href="/api/accounting/export/${kind}.csv?${qs}" download>${esc(label)} ↓</a>`).join('');
      $('#accAudit').innerHTML = audit.length ? audit.slice(0, 60).map(a => `<div class="sales-item"><div><strong>${esc(a.entity)} #${esc(a.entity_id)} · ${esc(a.action.replaceAll('_', ' '))}</strong><small>${esc(a.ts)} UTC · ${esc(a.detail)}</small></div></div>`).join('') : '<div class="empty">Noch keine Einträge.</div>';
    } catch (err) { toast(err.message, true); }
  }

  // ------------------------------------------------------------ Stammdaten & Backup (Einstellungen → Meine Firma, Sicherung & Zugang)
  async function loadSettings() {
    if (!$('#accSettingsForm')) return;
    try {
      settings = await api('/accounting/settings');
      const f = $('#accSettingsForm');
      for (const el of f.elements) {
        if (!el.name || !(el.name in settings)) continue;
        if (el.type === 'checkbox') el.checked = !!settings[el.name]; else el.value = settings[el.name] ?? '';
      }
      const b = await api('/backups');
      if ($('#accBackupInfo')) $('#accBackupInfo').innerHTML = `<small class="muted">Ordner: ${esc(b.folder)}</small>` + (b.backups.length ? b.backups.slice(0, 8).map(x => `<div class="sales-item"><div><strong>${esc(x.name)}</strong><small>${esc(x.modified)} · ${(x.size_bytes / 1024).toFixed(0)} KB</small></div></div>`).join('') : '<div class="empty">Noch kein Backup erstellt.</div>');
    } catch (e) { toast(e.message, true); }
  }
  window.accLoadSettings = loadSettings;

  async function saveSettings(e) {
    e.preventDefault();
    const f = e.target, d = Object.fromEntries(new FormData(f).entries());
    d.small_business = f.elements.small_business.checked;
    d.payment_days = Number(d.payment_days || 0);
    try { settings = await api('/accounting/settings', 'PUT', d); toast(settings.missing.length ? 'Gespeichert – noch fehlend: ' + settings.missing.join(', ') : 'Stammdaten gespeichert'); loadSettings(); }
    catch (err) { toast(err.message, true); }
  }

  // ------------------------------------------------------------ Events
  function init() {
    if (!$('#viewAccounting')) return;
    $('#accQ').addEventListener('input', renderInvoices);
    $('#accInvoiceFilter').addEventListener('change', renderInvoices);
    $('#accViews').addEventListener('click', e => { const b = e.target.closest('[data-acc-view]'); if (b) { invView = b.dataset.accView; renderInvoices(); } });
    $('#accFilterReset').addEventListener('click', () => { $('#accInvoiceFilter').value = ''; $('#accQ').value = ''; invView = 'alle'; renderInvoices(); });
    $('#accRefresh').addEventListener('click', () => window.refreshAccounting('accounting'));
    $('#accNewInvoice').addEventListener('click', () => openEditor(null));
    $('#accEditorClose').addEventListener('click', () => { setMode('list'); loadInvoices(); });
    $('#accAddLine').addEventListener('click', () => { $('#accLines').insertAdjacentHTML('beforeend', lineRow()); updateTotals(); });
    $('#accInvoiceForm').addEventListener('input', updateTotals);
    $('#accInvoiceForm').addEventListener('change', updateTotals);
    $('#accInvoiceForm').addEventListener('submit', saveDraft);
    $('#accFinalize').addEventListener('click', finalize);
    $('#accPreview').addEventListener('click', () => editingId && window.open('/rechnung/' + editingId, '_blank', 'noopener'));
    $('#accDeleteDraft').addEventListener('click', async () => {
      if (!editingId || !confirm('Entwurf löschen?')) return;
      try { await api('/accounting/invoices/' + editingId, 'DELETE'); toast('Entwurf gelöscht'); setMode('list'); loadInvoices(); }
      catch (e) { toast(e.message, true); }
    });
    $('#accLeadSelect').addEventListener('change', async e => {
      if (!e.target.value) return;
      try {
        const d = await api('/accounting/buyer-defaults?lead_id=' + e.target.value), f = $('#accInvoiceForm');
        for (const [k, v] of Object.entries(d)) if (f.elements[k] && !f.elements[k].value.trim()) f.elements[k].value = v ?? '';
        if (!f.elements.buyer_name.value.trim() && d.buyer_name) f.elements.buyer_name.value = d.buyer_name;
      } catch (err) { toast(err.message, true); }
    });
    $('#accExpenseForm').addEventListener('submit', saveExpense);
    $('#accEinvoiceFile').addEventListener('change', importEinvoice);
    $('#accShowCancelled').addEventListener('change', loadExpenses);
    $('#accPreset').addEventListener('change', () => { applyPreset(); loadReport(); });
    $('#accReportForm').addEventListener('submit', loadReport);
    $('#accReportForm').addEventListener('input', e => { if (e.target.type === 'date') $('#accPreset').value = 'custom'; });
    $('#accSettingsForm')?.addEventListener('submit', saveSettings);
    $('#accBackup')?.addEventListener('click', async () => {
      try { const b = await api('/backup', 'POST', {}); toast('Backup erstellt: ' + b.path); loadSettings(); } catch (e) { toast(e.message, true); }
    });
    // Ausgaben, Auswertung und Steuer laden beim Wechsel des Reiters (Rechnungen lädt app.js über refreshAccounting)
    document.addEventListener('signaldesk:view', e => { if (['expenses', 'revenue', 'tax'].includes(e.detail.view)) window.refreshAccounting(e.detail.view); });
    $('#viewAccounting').addEventListener('submit', e => {
      if (e.target.id === 'accPaymentForm') { e.preventDefault(); submitPayment(e.target); }
      if (e.target.id === 'accDunningForm') { e.preventDefault(); submitDunning(e.target); }
    });
    $('#viewAccounting').addEventListener('keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('[data-acc-open]')) { e.preventDefault(); openInvoice(Number(e.target.dataset.accOpen)); } });
    document.addEventListener('click', async e => {
      const t = e.target;
      if (!t.closest('#viewAccounting, #viewExpenses, #viewRevenue, #viewTax')) return;
      const open = t.closest('[data-acc-open]');
      if (open) { if (currentView !== 'accounting') switchView('accounting'); return openInvoice(Number(open.dataset.accOpen)); }
      const fp = t.closest('[data-acc-from-proposal]');
      if (fp) return fromProposal(Number(fp.dataset.accFromProposal), fp.dataset.mode);
      if (t.closest('[data-acc-del-line]')) { const rows = $$('#accLines .acc-line'); if (rows.length > 1) t.closest('tr').remove(); updateTotals(); return; }
      if (t.closest('[data-acc-close-detail]')) { setMode('list'); return; }
      const dup = t.closest('[data-acc-duplicate]');
      if (dup) { try { const inv = await api(`/accounting/invoices/${dup.dataset.accDuplicate}/duplicate`, 'POST', {}); toast('Kopie als Entwurf angelegt – Leistungsdatum ergänzen'); loadInvoices(); openEditor(inv); } catch (err) { toast(err.message, true); } return; }
      const cancel = t.closest('[data-acc-cancel]');
      if (cancel) {
        const reason = prompt('Rechnung stornieren? Es wird eine Stornorechnung mit eigener Nummer erzeugt.\nGrund (optional):');
        if (reason === null) return;
        try { const s = await api(`/accounting/invoices/${cancel.dataset.accCancel}/cancel`, 'POST', {confirm: true, reason}); toast(`Stornorechnung ${s.number} erstellt`); loadInvoices(); showDetail(s); } catch (err) { toast(err.message, true); }
        return;
      }
      const delPay = t.closest('[data-acc-del-payment]');
      if (delPay) { if (!confirm('Zahlung zurücknehmen? Der Vorgang wird protokolliert.')) return; try { const inv = await api('/accounting/payments/' + delPay.dataset.accDelPayment, 'DELETE'); showDetail(inv); loadInvoices(); } catch (err) { toast(err.message, true); } return; }
      const paid = t.closest('[data-acc-exp-paid]');
      if (paid) { try { await api(`/accounting/expenses/${paid.dataset.accExpPaid}/paid`, 'POST', {paid_on: iso(new Date())}); loadExpenses(); } catch (err) { toast(err.message, true); } return; }
      const ec = t.closest('[data-acc-exp-cancel]');
      if (ec) { const reason = prompt('Ausgabe stornieren? Grund:'); if (reason === null) return; try { await api(`/accounting/expenses/${ec.dataset.accExpCancel}/cancel`, 'POST', {confirm: true, reason}); toast('Ausgabe storniert'); loadExpenses(); } catch (err) { toast(err.message, true); } }
    });
  }
  init();
})();
